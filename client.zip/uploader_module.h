#pragma once
#ifndef UPLOADER_MODULE_H
#define UPLOADER_MODULE_H

int run_file_upload(const char* folder);


#endif