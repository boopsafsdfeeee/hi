import json
from django.shortcuts import get_object_or_404
from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse, HttpResponse # HttpResponse 임포트
from django.db.models import Q 
from django.utils import timezone

from .models import CommandTask, Client 

@csrf_exempt
def poll_command_view(request):
    """
    클라이언트로부터 폴링 요청을 받아, 대기 중인 명령을 할당하거나 빈 응답을 반환합니다.
    """
    client_id = request.GET.get('client_id')

    if not client_id:
        return JsonResponse({"status": "error", "message": "Client ID missing"}, status=400)

    # Client 모델 생성 또는 last_seen 업데이트
    client, created = Client.objects.update_or_create(
        client_id=client_id,
        defaults={'client_id': client_id}
    )
    
    try:
        command = CommandTask.objects.filter(
            Q(client__isnull=True) | Q(client=client)
        ).filter(status='PENDING').order_by('created_at').first()

    except Exception as e:
        print(f"[CRITICAL ERROR in poll_command_view] {e}")
        return JsonResponse({"status": "error", "message": "Internal Server Error during query"}, status=500)


    if command:
        command.status = 'ASSIGNED'
        
        if command.client is None:
             command.client = client
             
        command.save()

        response_data = {
            "status": "command_assigned",
            "command_id": command.id,
            "command_name": command.command_name,
            "client_id": client.client_id,
            "payload": command.payload
        }
        print(f"[INFO] 명령 할당: Task ID {command.id} to {client_id}")
        return JsonResponse(response_data)
    else:
        return JsonResponse({"status": "no_command", "message": "No pending commands."})

@csrf_exempt
def receive_upload_view(request):
    """
    클라이언트가 명령 실행 결과를 JSON으로 POST하는 것을 받습니다.
    """
    if request.method != 'POST':
        return JsonResponse({"status": "error", "message": "Only POST requests allowed"}, status=405)

    try:
        data = json.loads(request.body)
        
        command_id = data.get('command_id')
        status = data.get('status')
        exit_code = data.get('exit_code')
        filename = data.get('filename')
        file_content = data.get('file_content')

        task = get_object_or_404(CommandTask, id=command_id)

        # 결과 업데이트
        task.status = status
        task.exit_code = exit_code
        task.result_filename = filename
        task.result_content = file_content 
        task.save()
        
        print(f"[INFO] Task ID {command_id} 결과 수신. 상태: {status}, 파일: {filename}")
        
        return JsonResponse({"status": "success", "message": "Result uploaded successfully."})

    except CommandTask.DoesNotExist:
        return JsonResponse({"status": "error", "message": "CommandTask not found"}, status=404)
    except json.JSONDecodeError:
        return JsonResponse({"status": "error", "message": "Invalid JSON"}, status=400)
    except Exception as e:
        print(f"[CRITICAL ERROR in receive_upload_view] {e}")
        return JsonResponse({"status": "error", "message": "Internal Server Error"}, status=500)


# 🚩 새로 추가된 뷰 함수
def download_result_view(request, task_id):
    """
    관리자 페이지에서 명령 실행 결과를 다운로드할 수 있도록 파일을 제공합니다.
    """
    task = get_object_or_404(CommandTask, id=task_id)

    if not task.result_content:
        # 내용이 없는 경우 404 또는 메시지 반환
        return HttpResponse("명령 결과 내용이 없습니다.", status=404)

    # 응답 생성
    # Content-Type을 'application/octet-stream'으로 설정하여 파일 다운로드를 강제합니다.
    response = HttpResponse(task.result_content, content_type='application/octet-stream')

    # 파일 다운로드를 위한 헤더 설정
    filename = task.result_filename if task.result_filename else f"task_result_{task_id}.txt"
    response['Content-Disposition'] = f'attachment; filename="{filename}"'
    
    return response