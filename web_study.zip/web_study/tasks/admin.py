from django.contrib import admin
from django.urls import reverse
from django.utils.safestring import mark_safe
from django.utils import timezone
from datetime import timedelta
from .models import Client, CommandTask
import json

@admin.register(Client)
class ClientAdmin(admin.ModelAdmin):
    list_display = ('client_id', 'last_seen', 'is_active', 'action_send_command')
    search_fields = ('client_id',)
    list_filter = ('last_seen',)

    @admin.display(description='활성 상태', boolean=True)
    def is_active(self, obj):
        return (timezone.now() - obj.last_seen).total_seconds() < 30
    
    @admin.display(description='명령 전송')
    def action_send_command(self, obj):
        url = (
            reverse("admin:tasks_commandtask_add") + 
            f"?client={obj.id}" 
        )
        return mark_safe(f'<a class="button" href="{url}">명령 보내기</a>')

        
@admin.register(CommandTask)
class CommandTaskAdmin(admin.ModelAdmin):
    list_display = ('id', 'command_name', 'client', 'status', 'created_at', 'get_download_link') 
    list_filter = ('status', 'client')
    search_fields = ('client__client_id', 'command_name') 
    list_per_page = 25
    
    @admin.display(description='결과 파일')
    def get_download_link(self, obj):
        if obj.result_content and obj.status in ['COMPLETED', 'FAILED']:
            url = reverse('download_result', args=[obj.id])
            filename = obj.result_filename if obj.result_filename else f"Task-{obj.id}_result.txt"
            return mark_safe(f'<a href="{url}" class="button" target="_blank">{filename} (다운로드)</a>')
        return "-"

    def get_changeform_initial_data(self, request):
        initial = super().get_changeform_initial_data(request)
        
        if 'client' in request.GET:
            try:
                client_id = int(request.GET['client'])
                initial['client'] = client_id
            except ValueError:
                pass 

        return initial
    
    # 🚩 1. fields 튜플: payload_json 없이 'payload'만 사용합니다.
    fields = ('client', 'command_name', 'payload', 'status', 'result_filename', 'result_content', 'created_at')
    readonly_fields = ('status', 'result_filename', 'result_content', 'created_at')

    def get_fields(self, request, obj=None):
        if obj is None: # Task 생성 시
            # 🚩 2. get_fields (생성): payload_json 없이 'payload'만 사용합니다.
            return ('client', 'command_name', 'payload')
        return self.fields

    def save_model(self, request, obj, form, change):
        if not change:
            obj.status = 'PENDING'
        super().save_model(request, obj, form, change)