from django.db import models
from django.utils import timezone

class Client(models.Model):
    """
    폴링하는 각 클라이언트/작업자(Worker)의 상태를 추적하는 모델
    """
    client_id = models.CharField(max_length=100, unique=True, verbose_name="클라이언트 ID")
    # auto_now=True: 레코드가 저장될 때마다 현재 시간으로 자동 업데이트됨 (클라이언트 활성 상태 추적)
    last_seen = models.DateTimeField(auto_now=True, verbose_name="마지막 접속 시간")

    def __str__(self):
        return self.client_id

    class Meta:
        verbose_name = "클라이언트"
        verbose_name_plural = "클라이언트 목록"

class CommandTask(models.Model):
    """
    Worker에게 보낼 쉘 명령(Command)을 저장하는 모델
    """
    STATUS_CHOICES = [
        ('PENDING', '대기 중'),
        ('ASSIGNED', '할당됨'),
        ('COMPLETED', '완료됨'),
        ('FAILED', '실패'),
    ]

    command_name = models.CharField(max_length=100, default='EXECUTE_SHELL', verbose_name="명령 유형")
    
    # 특정 클라이언트에게 할당
    client = models.ForeignKey(
        Client, 
        on_delete=models.SET_NULL, 
        null=True, 
        blank=True, 
        verbose_name="할당된 클라이언트"
    )

    # 🚩 JSONField만 사용하도록 통일합니다.
    payload = models.JSONField(verbose_name="명령 내용(JSON)", default=dict) 
    # 🚩 중복 필드였던 payload_json은 제거되었습니다.

    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='PENDING', verbose_name="상태")
    exit_code = models.IntegerField(null=True, blank=True, verbose_name="종료 코드")
    
    # 결과 파일 저장용 필드
    result_filename = models.CharField(max_length=255, null=True, blank=True, verbose_name="결과 파일명")
    result_content = models.TextField(null=True, blank=True, verbose_name="결과 내용")

    created_at = models.DateTimeField(auto_now_add=True, verbose_name="생성 시간")
    updated_at = models.DateTimeField(auto_now=True, verbose_name="업데이트 시간")

    def __str__(self):
        client_name = self.client.client_id if self.client else '모든 클라이언트'
        return f"Task #{self.id} - {self.command_name} to {client_name}"

    class Meta:
        verbose_name = "명령 작업"
        verbose_name_plural = "명령 작업 목록"
        ordering = ['created_at']